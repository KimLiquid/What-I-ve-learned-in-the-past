﻿Public Class ddd

    Dim jeokMove As Integer = 1

    Private Sub ddd_KeyDown(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles Me.KeyDown
        If e.KeyValue = Keys.Right Then
            behainggi.Left += 5
            If behainggi.Left = 600 Then
                behainggi.Left = -50
            End If
        End If
        If e.KeyValue = Keys.Left Then
            behainggi.Left -= 5
            If behainggi.Left = -50 Then
                behainggi.Left = 600
            End If
        End If

        If e.KeyValue = Keys.Space Then
            picbullA.Left = behainggi.Left + 65
            picbullB.Left = behainggi.Left + 25
            picbullC.Left = behainggi.Left + 45
            picbullA.Visible = True
            picbullB.Visible = True
            picbullC.Visible = True
            ' tim.Enabled = true

        End If
    End Sub

    Private Sub behainggi_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles behainggi.Click

    End Sub

    Private Sub PictureBox1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles picbullA.Click
        If picbullA.Visible = True Then
            picbullA.Top -= 10
        End If
    End Sub

    Private Sub tenr_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles picbullC.Click
        If picbullC.Visible = True Then
            picbullC.Top -= 10
        End If
    End Sub

    Private Sub PictureBox2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles picbullB.Click
        If picbullB.Visible = True Then
            picbullB.Top -= 10
        End If
    End Sub

    Private Sub jeokRightMove()
        o1.Left += 1
        o2.Left += 2
        o3.Left += 1
        o4.Left += 2
        o5.Left += 1
        o6.Left += 2
        o7.Left += 1
        o8.Left += 2
        o9.Left += 1
        o10.Left += 2
        o11.Left += 1
        o12.Left += 2
        o13.Left += 1
        o14.Left += 2
        o15.Left += 1
        o16.Left += 2
        o17.Left += 1
        o18.Left += 2
        o19.Left += 1
        o20.Left += 2
        o21.Left += 1
        o22.Left += 2
        o23.Left += 1
        o24.Left += 2
        o25.Left += 1
        o26.Left += 2
        o27.Left += 1
        o28.Left += 2
        o29.Left += 1
        o30.Left += 2
        o31.Left += 1
        o32.Left += 2
        o33.Left += 1
        o34.Left += 2
        o35.Left += 1
        o36.Left += 2
        o37.Left += 1
        o38.Left += 2
        o39.Left += 1
        o40.Left += 2
        o41.Left += 1
        o42.Left += 2
        o43.Left += 1
        o44.Left += 2
        o45.Left += 1
        o46.Left += 2
        o47.Left += 1
        o48.Left += 2
        o49.Left += 1
        o50.Left += 2
        o51.Left += 1
        o52.Left += 2
        o53.Left += 1
        o54.Left += 2
        o55.Left += 1
        o56.Left += 2
        o57.Left += 1
        o58.Left += 2
        o59.Left += 1
        o60.Left += 2
        o61.Left += 1
        o62.Left += 2
        o63.Left += 1
        o64.Left += 2
        o65.Left += 1
        o66.Left += 2
        o67.Left += 1
        o68.Left += 2
        o69.Left += 1
        o70.Left += 2
        o71.Left += 1
        o72.Left += 2
        o73.Left += 1
        o74.Left += 2
        o75.Left += 1
        o76.Left += 2
        o77.Left += 1
        o78.Left += 2
        o79.Left += 1
        o80.Left += 2
        o81.Left += 1
        o82.Left += 2
        o83.Left += 1
        o84.Left += 2
        o85.Left += 1
        o86.Left += 2
        o87.Left += 1
        o88.Left += 2
        o89.Left += 1
        o90.Left += 2
        o91.Left += 1
        o92.Left += 2
        o93.Left += 1
        o94.Left += 2
        o95.Left += 1
        o96.Left += 2
        o97.Left += 1
        o98.Left += 2
        o99.Left += 1
        o100.Left += 2
        o101.Left += 1
        o102.Left += 2
        o103.Left += 1
        o104.Left += 2
        o105.Left += 1
    End Sub
    Private Sub jeokleftMove()
        o1.Left -= 1
        o2.Left -= 2
        o3.Left -= 1
        o4.Left -= 2
        o5.Left -= 1
        o6.Left -= 2
        o7.Left -= 1
        o8.Left -= 2
        o9.Left -= 1
        o10.Left -= 2
        o11.Left -= 1
        o12.Left -= 2
        o13.Left -= 1
        o14.Left -= 2
        o15.Left -= 1
        o16.Left -= 2
        o17.Left -= 1
        o18.Left -= 2
        o19.Left -= 1
        o20.Left -= 2
        o21.Left -= 1
        o22.Left -= 2
        o23.Left -= 1
        o24.Left -= 2
        o25.Left -= 1
        o26.Left -= 2
        o27.Left -= 1
        o28.Left -= 2
        o29.Left -= 1
        o30.Left -= 2
        o31.Left -= 1
        o32.Left -= 2
        o33.Left -= 1
        o34.Left -= 2
        o35.Left -= 1
        o36.Left -= 2
        o37.Left -= 1
        o38.Left -= 2
        o39.Left -= 1
        o40.Left -= 2
        o41.Left -= 1
        o42.Left -= 2
        o43.Left -= 1
        o44.Left -= 2
        o45.Left -= 1
        o46.Left -= 2
        o47.Left -= 1
        o48.Left -= 2
        o49.Left -= 1
        o50.Left -= 2
        o51.Left -= 1
        o52.Left -= 2
        o53.Left -= 1
        o54.Left -= 2
        o55.Left -= 1
        o56.Left -= 2
        o57.Left -= 1
        o58.Left -= 2
        o59.Left -= 1
        o60.Left -= 2
        o61.Left -= 1
        o62.Left -= 2
        o63.Left -= 1
        o64.Left -= 2
        o65.Left -= 1
        o66.Left -= 2
        o67.Left -= 1
        o68.Left -= 2
        o69.Left -= 1
        o70.Left -= 2
        o71.Left -= 1
        o72.Left -= 2
        o73.Left -= 1
        o74.Left -= 2
        o75.Left -= 1
        o76.Left -= 2
        o77.Left -= 1
        o78.Left -= 2
        o79.Left -= 1
        o80.Left -= 2
        o81.Left -= 1
        o82.Left -= 2
        o83.Left -= 1
        o84.Left -= 2
        o85.Left -= 1
        o86.Left -= 2
        o87.Left -= 1
        o88.Left -= 2
        o89.Left -= 1
        o90.Left -= 2
        o91.Left += 1
        o92.Left += 2
        o93.Left += 1
        o94.Left += 2
        o95.Left += 1
        o96.Left += 2
        o97.Left += 1
        o98.Left += 2
        o99.Left += 1
        o100.Left += 2
        o101.Left += 1
        o102.Left += 2
        o103.Left += 1
        o104.Left += 2
        o105.Left += 1
    End Sub
End Class
