﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class ddd
    Inherits System.Windows.Forms.Form

    'Form은 Dispose를 재정의하여 구성 요소 목록을 정리합니다.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Windows Form 디자이너에 필요합니다.
    Private components As System.ComponentModel.IContainer

    '참고: 다음 프로시저는 Windows Form 디자이너에 필요합니다.
    '수정하려면 Windows Form 디자이너를 사용하십시오.  
    '코드 편집기를 사용하여 수정하지 마십시오.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(ddd))
        Me.PictureBox168 = New System.Windows.Forms.PictureBox()
        Me.PictureBox84 = New System.Windows.Forms.PictureBox()
        Me.PictureBox167 = New System.Windows.Forms.PictureBox()
        Me.PictureBox166 = New System.Windows.Forms.PictureBox()
        Me.PictureBox165 = New System.Windows.Forms.PictureBox()
        Me.PictureBox160 = New System.Windows.Forms.PictureBox()
        Me.PictureBox159 = New System.Windows.Forms.PictureBox()
        Me.PictureBox82 = New System.Windows.Forms.PictureBox()
        Me.PictureBox158 = New System.Windows.Forms.PictureBox()
        Me.PictureBox157 = New System.Windows.Forms.PictureBox()
        Me.PictureBox152 = New System.Windows.Forms.PictureBox()
        Me.PictureBox151 = New System.Windows.Forms.PictureBox()
        Me.PictureBox80 = New System.Windows.Forms.PictureBox()
        Me.PictureBox150 = New System.Windows.Forms.PictureBox()
        Me.PictureBox149 = New System.Windows.Forms.PictureBox()
        Me.PictureBox144 = New System.Windows.Forms.PictureBox()
        Me.PictureBox143 = New System.Windows.Forms.PictureBox()
        Me.PictureBox78 = New System.Windows.Forms.PictureBox()
        Me.PictureBox142 = New System.Windows.Forms.PictureBox()
        Me.PictureBox141 = New System.Windows.Forms.PictureBox()
        Me.PictureBox136 = New System.Windows.Forms.PictureBox()
        Me.PictureBox76 = New System.Windows.Forms.PictureBox()
        Me.PictureBox134 = New System.Windows.Forms.PictureBox()
        Me.PictureBox132 = New System.Windows.Forms.PictureBox()
        Me.PictureBox131 = New System.Windows.Forms.PictureBox()
        Me.PictureBox74 = New System.Windows.Forms.PictureBox()
        Me.PictureBox129 = New System.Windows.Forms.PictureBox()
        Me.PictureBox128 = New System.Windows.Forms.PictureBox()
        Me.PictureBox126 = New System.Windows.Forms.PictureBox()
        Me.PictureBox123 = New System.Windows.Forms.PictureBox()
        Me.PictureBox72 = New System.Windows.Forms.PictureBox()
        Me.PictureBox121 = New System.Windows.Forms.PictureBox()
        Me.PictureBox120 = New System.Windows.Forms.PictureBox()
        Me.PictureBox118 = New System.Windows.Forms.PictureBox()
        Me.PictureBox115 = New System.Windows.Forms.PictureBox()
        Me.PictureBox70 = New System.Windows.Forms.PictureBox()
        Me.PictureBox113 = New System.Windows.Forms.PictureBox()
        Me.PictureBox112 = New System.Windows.Forms.PictureBox()
        Me.PictureBox110 = New System.Windows.Forms.PictureBox()
        Me.PictureBox107 = New System.Windows.Forms.PictureBox()
        Me.PictureBox68 = New System.Windows.Forms.PictureBox()
        Me.PictureBox105 = New System.Windows.Forms.PictureBox()
        Me.PictureBox104 = New System.Windows.Forms.PictureBox()
        Me.PictureBox102 = New System.Windows.Forms.PictureBox()
        Me.PictureBox99 = New System.Windows.Forms.PictureBox()
        Me.PictureBox66 = New System.Windows.Forms.PictureBox()
        Me.PictureBox97 = New System.Windows.Forms.PictureBox()
        Me.PictureBox96 = New System.Windows.Forms.PictureBox()
        Me.PictureBox94 = New System.Windows.Forms.PictureBox()
        Me.PictureBox88 = New System.Windows.Forms.PictureBox()
        Me.behainggi = New System.Windows.Forms.PictureBox()
        Me.picbullB = New System.Windows.Forms.PictureBox()
        Me.picbullA = New System.Windows.Forms.PictureBox()
        Me.picbullC = New System.Windows.Forms.PictureBox()
        Me.PictureBox232 = New System.Windows.Forms.PictureBox()
        Me.PictureBox233 = New System.Windows.Forms.PictureBox()
        Me.PictureBox235 = New System.Windows.Forms.PictureBox()
        Me.PictureBox237 = New System.Windows.Forms.PictureBox()
        Me.PictureBox239 = New System.Windows.Forms.PictureBox()
        Me.PictureBox241 = New System.Windows.Forms.PictureBox()
        Me.PictureBox243 = New System.Windows.Forms.PictureBox()
        Me.PictureBox245 = New System.Windows.Forms.PictureBox()
        Me.PictureBox247 = New System.Windows.Forms.PictureBox()
        Me.PictureBox249 = New System.Windows.Forms.PictureBox()
        Me.PictureBox251 = New System.Windows.Forms.PictureBox()
        Me.PictureBox253 = New System.Windows.Forms.PictureBox()
        Me.PictureBox254 = New System.Windows.Forms.PictureBox()
        Me.PictureBox256 = New System.Windows.Forms.PictureBox()
        Me.PictureBox258 = New System.Windows.Forms.PictureBox()
        Me.PictureBox260 = New System.Windows.Forms.PictureBox()
        Me.PictureBox262 = New System.Windows.Forms.PictureBox()
        Me.PictureBox264 = New System.Windows.Forms.PictureBox()
        Me.PictureBox266 = New System.Windows.Forms.PictureBox()
        Me.PictureBox268 = New System.Windows.Forms.PictureBox()
        Me.PictureBox270 = New System.Windows.Forms.PictureBox()
        Me.PictureBox272 = New System.Windows.Forms.PictureBox()
        Me.PictureBox274 = New System.Windows.Forms.PictureBox()
        Me.PictureBox275 = New System.Windows.Forms.PictureBox()
        Me.PictureBox277 = New System.Windows.Forms.PictureBox()
        Me.PictureBox279 = New System.Windows.Forms.PictureBox()
        Me.PictureBox281 = New System.Windows.Forms.PictureBox()
        Me.PictureBox283 = New System.Windows.Forms.PictureBox()
        Me.PictureBox285 = New System.Windows.Forms.PictureBox()
        Me.PictureBox287 = New System.Windows.Forms.PictureBox()
        Me.PictureBox289 = New System.Windows.Forms.PictureBox()
        Me.PictureBox291 = New System.Windows.Forms.PictureBox()
        Me.PictureBox293 = New System.Windows.Forms.PictureBox()
        Me.PictureBox295 = New System.Windows.Forms.PictureBox()
        Me.PictureBox296 = New System.Windows.Forms.PictureBox()
        Me.PictureBox298 = New System.Windows.Forms.PictureBox()
        Me.PictureBox300 = New System.Windows.Forms.PictureBox()
        Me.PictureBox302 = New System.Windows.Forms.PictureBox()
        Me.PictureBox304 = New System.Windows.Forms.PictureBox()
        Me.PictureBox306 = New System.Windows.Forms.PictureBox()
        Me.PictureBox308 = New System.Windows.Forms.PictureBox()
        Me.PictureBox310 = New System.Windows.Forms.PictureBox()
        Me.PictureBox312 = New System.Windows.Forms.PictureBox()
        Me.PictureBox314 = New System.Windows.Forms.PictureBox()
        Me.PictureBox316 = New System.Windows.Forms.PictureBox()
        Me.PictureBox317 = New System.Windows.Forms.PictureBox()
        Me.PictureBox319 = New System.Windows.Forms.PictureBox()
        Me.PictureBox321 = New System.Windows.Forms.PictureBox()
        Me.PictureBox323 = New System.Windows.Forms.PictureBox()
        Me.PictureBox325 = New System.Windows.Forms.PictureBox()
        Me.PictureBox327 = New System.Windows.Forms.PictureBox()
        Me.PictureBox329 = New System.Windows.Forms.PictureBox()
        Me.PictureBox331 = New System.Windows.Forms.PictureBox()
        Me.PictureBox333 = New System.Windows.Forms.PictureBox()
        Me.PictureBox335 = New System.Windows.Forms.PictureBox()
        Me.PictureBox2 = New System.Windows.Forms.PictureBox()
        CType(Me.PictureBox168, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox84, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox167, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox166, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox165, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox160, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox159, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox82, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox158, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox157, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox152, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox151, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox80, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox150, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox149, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox144, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox143, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox78, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox142, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox141, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox136, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox76, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox134, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox132, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox131, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox74, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox129, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox128, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox126, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox123, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox72, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox121, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox120, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox118, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox115, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox70, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox113, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox112, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox110, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox107, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox68, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox105, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox104, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox102, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox99, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox66, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox97, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox96, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox94, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox88, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.behainggi, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picbullB, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picbullA, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picbullC, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox232, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox233, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox235, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox237, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox239, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox241, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox243, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox245, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox247, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox249, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox251, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox253, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox254, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox256, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox258, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox260, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox262, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox264, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox266, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox268, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox270, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox272, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox274, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox275, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox277, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox279, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox281, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox283, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox285, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox287, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox289, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox291, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox293, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox295, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox296, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox298, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox300, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox302, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox304, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox306, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox308, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox310, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox312, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox314, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox316, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox317, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox319, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox321, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox323, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox325, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox327, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox329, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox331, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox333, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox335, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox2, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'PictureBox168
        '
        Me.PictureBox168.Image = CType(resources.GetObject("PictureBox168.Image"), System.Drawing.Image)
        Me.PictureBox168.Location = New System.Drawing.Point(524, 532)
        Me.PictureBox168.Name = "PictureBox168"
        Me.PictureBox168.Size = New System.Drawing.Size(21, 23)
        Me.PictureBox168.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.PictureBox168.TabIndex = 2
        Me.PictureBox168.TabStop = False
        '
        'PictureBox84
        '
        Me.PictureBox84.Image = CType(resources.GetObject("PictureBox84.Image"), System.Drawing.Image)
        Me.PictureBox84.Location = New System.Drawing.Point(524, 234)
        Me.PictureBox84.Name = "PictureBox84"
        Me.PictureBox84.Size = New System.Drawing.Size(21, 23)
        Me.PictureBox84.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.PictureBox84.TabIndex = 2
        Me.PictureBox84.TabStop = False
        '
        'PictureBox167
        '
        Me.PictureBox167.Image = CType(resources.GetObject("PictureBox167.Image"), System.Drawing.Image)
        Me.PictureBox167.Location = New System.Drawing.Point(524, 458)
        Me.PictureBox167.Name = "PictureBox167"
        Me.PictureBox167.Size = New System.Drawing.Size(21, 23)
        Me.PictureBox167.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.PictureBox167.TabIndex = 2
        Me.PictureBox167.TabStop = False
        '
        'PictureBox166
        '
        Me.PictureBox166.Image = CType(resources.GetObject("PictureBox166.Image"), System.Drawing.Image)
        Me.PictureBox166.Location = New System.Drawing.Point(524, 384)
        Me.PictureBox166.Name = "PictureBox166"
        Me.PictureBox166.Size = New System.Drawing.Size(21, 23)
        Me.PictureBox166.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.PictureBox166.TabIndex = 2
        Me.PictureBox166.TabStop = False
        '
        'PictureBox165
        '
        Me.PictureBox165.Image = CType(resources.GetObject("PictureBox165.Image"), System.Drawing.Image)
        Me.PictureBox165.Location = New System.Drawing.Point(524, 310)
        Me.PictureBox165.Name = "PictureBox165"
        Me.PictureBox165.Size = New System.Drawing.Size(21, 23)
        Me.PictureBox165.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.PictureBox165.TabIndex = 2
        Me.PictureBox165.TabStop = False
        '
        'PictureBox160
        '
        Me.PictureBox160.Image = CType(resources.GetObject("PictureBox160.Image"), System.Drawing.Image)
        Me.PictureBox160.Location = New System.Drawing.Point(471, 532)
        Me.PictureBox160.Name = "PictureBox160"
        Me.PictureBox160.Size = New System.Drawing.Size(21, 23)
        Me.PictureBox160.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.PictureBox160.TabIndex = 2
        Me.PictureBox160.TabStop = False
        '
        'PictureBox159
        '
        Me.PictureBox159.Image = CType(resources.GetObject("PictureBox159.Image"), System.Drawing.Image)
        Me.PictureBox159.Location = New System.Drawing.Point(471, 458)
        Me.PictureBox159.Name = "PictureBox159"
        Me.PictureBox159.Size = New System.Drawing.Size(21, 23)
        Me.PictureBox159.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.PictureBox159.TabIndex = 2
        Me.PictureBox159.TabStop = False
        '
        'PictureBox82
        '
        Me.PictureBox82.Image = CType(resources.GetObject("PictureBox82.Image"), System.Drawing.Image)
        Me.PictureBox82.Location = New System.Drawing.Point(471, 234)
        Me.PictureBox82.Name = "PictureBox82"
        Me.PictureBox82.Size = New System.Drawing.Size(21, 23)
        Me.PictureBox82.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.PictureBox82.TabIndex = 2
        Me.PictureBox82.TabStop = False
        '
        'PictureBox158
        '
        Me.PictureBox158.Image = CType(resources.GetObject("PictureBox158.Image"), System.Drawing.Image)
        Me.PictureBox158.Location = New System.Drawing.Point(471, 384)
        Me.PictureBox158.Name = "PictureBox158"
        Me.PictureBox158.Size = New System.Drawing.Size(21, 23)
        Me.PictureBox158.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.PictureBox158.TabIndex = 2
        Me.PictureBox158.TabStop = False
        '
        'PictureBox157
        '
        Me.PictureBox157.Image = CType(resources.GetObject("PictureBox157.Image"), System.Drawing.Image)
        Me.PictureBox157.Location = New System.Drawing.Point(471, 310)
        Me.PictureBox157.Name = "PictureBox157"
        Me.PictureBox157.Size = New System.Drawing.Size(21, 23)
        Me.PictureBox157.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.PictureBox157.TabIndex = 2
        Me.PictureBox157.TabStop = False
        '
        'PictureBox152
        '
        Me.PictureBox152.Image = CType(resources.GetObject("PictureBox152.Image"), System.Drawing.Image)
        Me.PictureBox152.Location = New System.Drawing.Point(417, 532)
        Me.PictureBox152.Name = "PictureBox152"
        Me.PictureBox152.Size = New System.Drawing.Size(21, 23)
        Me.PictureBox152.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.PictureBox152.TabIndex = 2
        Me.PictureBox152.TabStop = False
        '
        'PictureBox151
        '
        Me.PictureBox151.Image = CType(resources.GetObject("PictureBox151.Image"), System.Drawing.Image)
        Me.PictureBox151.Location = New System.Drawing.Point(417, 458)
        Me.PictureBox151.Name = "PictureBox151"
        Me.PictureBox151.Size = New System.Drawing.Size(21, 23)
        Me.PictureBox151.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.PictureBox151.TabIndex = 2
        Me.PictureBox151.TabStop = False
        '
        'PictureBox80
        '
        Me.PictureBox80.Image = CType(resources.GetObject("PictureBox80.Image"), System.Drawing.Image)
        Me.PictureBox80.Location = New System.Drawing.Point(417, 234)
        Me.PictureBox80.Name = "PictureBox80"
        Me.PictureBox80.Size = New System.Drawing.Size(21, 23)
        Me.PictureBox80.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.PictureBox80.TabIndex = 2
        Me.PictureBox80.TabStop = False
        '
        'PictureBox150
        '
        Me.PictureBox150.Image = CType(resources.GetObject("PictureBox150.Image"), System.Drawing.Image)
        Me.PictureBox150.Location = New System.Drawing.Point(417, 384)
        Me.PictureBox150.Name = "PictureBox150"
        Me.PictureBox150.Size = New System.Drawing.Size(21, 23)
        Me.PictureBox150.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.PictureBox150.TabIndex = 2
        Me.PictureBox150.TabStop = False
        '
        'PictureBox149
        '
        Me.PictureBox149.Image = CType(resources.GetObject("PictureBox149.Image"), System.Drawing.Image)
        Me.PictureBox149.Location = New System.Drawing.Point(417, 310)
        Me.PictureBox149.Name = "PictureBox149"
        Me.PictureBox149.Size = New System.Drawing.Size(21, 23)
        Me.PictureBox149.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.PictureBox149.TabIndex = 2
        Me.PictureBox149.TabStop = False
        '
        'PictureBox144
        '
        Me.PictureBox144.Image = CType(resources.GetObject("PictureBox144.Image"), System.Drawing.Image)
        Me.PictureBox144.Location = New System.Drawing.Point(363, 532)
        Me.PictureBox144.Name = "PictureBox144"
        Me.PictureBox144.Size = New System.Drawing.Size(21, 23)
        Me.PictureBox144.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.PictureBox144.TabIndex = 2
        Me.PictureBox144.TabStop = False
        '
        'PictureBox143
        '
        Me.PictureBox143.Image = CType(resources.GetObject("PictureBox143.Image"), System.Drawing.Image)
        Me.PictureBox143.Location = New System.Drawing.Point(363, 458)
        Me.PictureBox143.Name = "PictureBox143"
        Me.PictureBox143.Size = New System.Drawing.Size(21, 23)
        Me.PictureBox143.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.PictureBox143.TabIndex = 2
        Me.PictureBox143.TabStop = False
        '
        'PictureBox78
        '
        Me.PictureBox78.Image = CType(resources.GetObject("PictureBox78.Image"), System.Drawing.Image)
        Me.PictureBox78.Location = New System.Drawing.Point(363, 234)
        Me.PictureBox78.Name = "PictureBox78"
        Me.PictureBox78.Size = New System.Drawing.Size(21, 23)
        Me.PictureBox78.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.PictureBox78.TabIndex = 2
        Me.PictureBox78.TabStop = False
        '
        'PictureBox142
        '
        Me.PictureBox142.Image = CType(resources.GetObject("PictureBox142.Image"), System.Drawing.Image)
        Me.PictureBox142.Location = New System.Drawing.Point(363, 384)
        Me.PictureBox142.Name = "PictureBox142"
        Me.PictureBox142.Size = New System.Drawing.Size(21, 23)
        Me.PictureBox142.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.PictureBox142.TabIndex = 2
        Me.PictureBox142.TabStop = False
        '
        'PictureBox141
        '
        Me.PictureBox141.Image = CType(resources.GetObject("PictureBox141.Image"), System.Drawing.Image)
        Me.PictureBox141.Location = New System.Drawing.Point(363, 310)
        Me.PictureBox141.Name = "PictureBox141"
        Me.PictureBox141.Size = New System.Drawing.Size(21, 23)
        Me.PictureBox141.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.PictureBox141.TabIndex = 2
        Me.PictureBox141.TabStop = False
        '
        'PictureBox136
        '
        Me.PictureBox136.Image = CType(resources.GetObject("PictureBox136.Image"), System.Drawing.Image)
        Me.PictureBox136.Location = New System.Drawing.Point(309, 532)
        Me.PictureBox136.Name = "PictureBox136"
        Me.PictureBox136.Size = New System.Drawing.Size(21, 23)
        Me.PictureBox136.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.PictureBox136.TabIndex = 2
        Me.PictureBox136.TabStop = False
        '
        'PictureBox76
        '
        Me.PictureBox76.Image = CType(resources.GetObject("PictureBox76.Image"), System.Drawing.Image)
        Me.PictureBox76.Location = New System.Drawing.Point(309, 234)
        Me.PictureBox76.Name = "PictureBox76"
        Me.PictureBox76.Size = New System.Drawing.Size(21, 23)
        Me.PictureBox76.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.PictureBox76.TabIndex = 2
        Me.PictureBox76.TabStop = False
        '
        'PictureBox134
        '
        Me.PictureBox134.Image = CType(resources.GetObject("PictureBox134.Image"), System.Drawing.Image)
        Me.PictureBox134.Location = New System.Drawing.Point(309, 458)
        Me.PictureBox134.Name = "PictureBox134"
        Me.PictureBox134.Size = New System.Drawing.Size(21, 23)
        Me.PictureBox134.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.PictureBox134.TabIndex = 2
        Me.PictureBox134.TabStop = False
        '
        'PictureBox132
        '
        Me.PictureBox132.Image = CType(resources.GetObject("PictureBox132.Image"), System.Drawing.Image)
        Me.PictureBox132.Location = New System.Drawing.Point(309, 384)
        Me.PictureBox132.Name = "PictureBox132"
        Me.PictureBox132.Size = New System.Drawing.Size(21, 23)
        Me.PictureBox132.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.PictureBox132.TabIndex = 2
        Me.PictureBox132.TabStop = False
        '
        'PictureBox131
        '
        Me.PictureBox131.Image = CType(resources.GetObject("PictureBox131.Image"), System.Drawing.Image)
        Me.PictureBox131.Location = New System.Drawing.Point(255, 532)
        Me.PictureBox131.Name = "PictureBox131"
        Me.PictureBox131.Size = New System.Drawing.Size(21, 23)
        Me.PictureBox131.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.PictureBox131.TabIndex = 2
        Me.PictureBox131.TabStop = False
        '
        'PictureBox74
        '
        Me.PictureBox74.Image = CType(resources.GetObject("PictureBox74.Image"), System.Drawing.Image)
        Me.PictureBox74.Location = New System.Drawing.Point(255, 234)
        Me.PictureBox74.Name = "PictureBox74"
        Me.PictureBox74.Size = New System.Drawing.Size(21, 23)
        Me.PictureBox74.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.PictureBox74.TabIndex = 2
        Me.PictureBox74.TabStop = False
        '
        'PictureBox129
        '
        Me.PictureBox129.Image = CType(resources.GetObject("PictureBox129.Image"), System.Drawing.Image)
        Me.PictureBox129.Location = New System.Drawing.Point(255, 458)
        Me.PictureBox129.Name = "PictureBox129"
        Me.PictureBox129.Size = New System.Drawing.Size(21, 23)
        Me.PictureBox129.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.PictureBox129.TabIndex = 2
        Me.PictureBox129.TabStop = False
        '
        'PictureBox128
        '
        Me.PictureBox128.Image = CType(resources.GetObject("PictureBox128.Image"), System.Drawing.Image)
        Me.PictureBox128.Location = New System.Drawing.Point(309, 310)
        Me.PictureBox128.Name = "PictureBox128"
        Me.PictureBox128.Size = New System.Drawing.Size(21, 23)
        Me.PictureBox128.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.PictureBox128.TabIndex = 2
        Me.PictureBox128.TabStop = False
        '
        'PictureBox126
        '
        Me.PictureBox126.Image = CType(resources.GetObject("PictureBox126.Image"), System.Drawing.Image)
        Me.PictureBox126.Location = New System.Drawing.Point(255, 384)
        Me.PictureBox126.Name = "PictureBox126"
        Me.PictureBox126.Size = New System.Drawing.Size(21, 23)
        Me.PictureBox126.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.PictureBox126.TabIndex = 2
        Me.PictureBox126.TabStop = False
        '
        'PictureBox123
        '
        Me.PictureBox123.Image = CType(resources.GetObject("PictureBox123.Image"), System.Drawing.Image)
        Me.PictureBox123.Location = New System.Drawing.Point(201, 532)
        Me.PictureBox123.Name = "PictureBox123"
        Me.PictureBox123.Size = New System.Drawing.Size(21, 23)
        Me.PictureBox123.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.PictureBox123.TabIndex = 2
        Me.PictureBox123.TabStop = False
        '
        'PictureBox72
        '
        Me.PictureBox72.Image = CType(resources.GetObject("PictureBox72.Image"), System.Drawing.Image)
        Me.PictureBox72.Location = New System.Drawing.Point(201, 234)
        Me.PictureBox72.Name = "PictureBox72"
        Me.PictureBox72.Size = New System.Drawing.Size(21, 23)
        Me.PictureBox72.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.PictureBox72.TabIndex = 2
        Me.PictureBox72.TabStop = False
        '
        'PictureBox121
        '
        Me.PictureBox121.Image = CType(resources.GetObject("PictureBox121.Image"), System.Drawing.Image)
        Me.PictureBox121.Location = New System.Drawing.Point(201, 458)
        Me.PictureBox121.Name = "PictureBox121"
        Me.PictureBox121.Size = New System.Drawing.Size(21, 23)
        Me.PictureBox121.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.PictureBox121.TabIndex = 2
        Me.PictureBox121.TabStop = False
        '
        'PictureBox120
        '
        Me.PictureBox120.Image = CType(resources.GetObject("PictureBox120.Image"), System.Drawing.Image)
        Me.PictureBox120.Location = New System.Drawing.Point(255, 310)
        Me.PictureBox120.Name = "PictureBox120"
        Me.PictureBox120.Size = New System.Drawing.Size(21, 23)
        Me.PictureBox120.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.PictureBox120.TabIndex = 2
        Me.PictureBox120.TabStop = False
        '
        'PictureBox118
        '
        Me.PictureBox118.Image = CType(resources.GetObject("PictureBox118.Image"), System.Drawing.Image)
        Me.PictureBox118.Location = New System.Drawing.Point(201, 384)
        Me.PictureBox118.Name = "PictureBox118"
        Me.PictureBox118.Size = New System.Drawing.Size(21, 23)
        Me.PictureBox118.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.PictureBox118.TabIndex = 2
        Me.PictureBox118.TabStop = False
        '
        'PictureBox115
        '
        Me.PictureBox115.Image = CType(resources.GetObject("PictureBox115.Image"), System.Drawing.Image)
        Me.PictureBox115.Location = New System.Drawing.Point(147, 532)
        Me.PictureBox115.Name = "PictureBox115"
        Me.PictureBox115.Size = New System.Drawing.Size(21, 23)
        Me.PictureBox115.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.PictureBox115.TabIndex = 2
        Me.PictureBox115.TabStop = False
        '
        'PictureBox70
        '
        Me.PictureBox70.Image = CType(resources.GetObject("PictureBox70.Image"), System.Drawing.Image)
        Me.PictureBox70.Location = New System.Drawing.Point(147, 234)
        Me.PictureBox70.Name = "PictureBox70"
        Me.PictureBox70.Size = New System.Drawing.Size(21, 23)
        Me.PictureBox70.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.PictureBox70.TabIndex = 2
        Me.PictureBox70.TabStop = False
        '
        'PictureBox113
        '
        Me.PictureBox113.Image = CType(resources.GetObject("PictureBox113.Image"), System.Drawing.Image)
        Me.PictureBox113.Location = New System.Drawing.Point(147, 458)
        Me.PictureBox113.Name = "PictureBox113"
        Me.PictureBox113.Size = New System.Drawing.Size(21, 23)
        Me.PictureBox113.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.PictureBox113.TabIndex = 2
        Me.PictureBox113.TabStop = False
        '
        'PictureBox112
        '
        Me.PictureBox112.Image = CType(resources.GetObject("PictureBox112.Image"), System.Drawing.Image)
        Me.PictureBox112.Location = New System.Drawing.Point(201, 310)
        Me.PictureBox112.Name = "PictureBox112"
        Me.PictureBox112.Size = New System.Drawing.Size(21, 23)
        Me.PictureBox112.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.PictureBox112.TabIndex = 2
        Me.PictureBox112.TabStop = False
        '
        'PictureBox110
        '
        Me.PictureBox110.Image = CType(resources.GetObject("PictureBox110.Image"), System.Drawing.Image)
        Me.PictureBox110.Location = New System.Drawing.Point(147, 384)
        Me.PictureBox110.Name = "PictureBox110"
        Me.PictureBox110.Size = New System.Drawing.Size(21, 23)
        Me.PictureBox110.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.PictureBox110.TabIndex = 2
        Me.PictureBox110.TabStop = False
        '
        'PictureBox107
        '
        Me.PictureBox107.Image = CType(resources.GetObject("PictureBox107.Image"), System.Drawing.Image)
        Me.PictureBox107.Location = New System.Drawing.Point(93, 532)
        Me.PictureBox107.Name = "PictureBox107"
        Me.PictureBox107.Size = New System.Drawing.Size(21, 23)
        Me.PictureBox107.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.PictureBox107.TabIndex = 2
        Me.PictureBox107.TabStop = False
        '
        'PictureBox68
        '
        Me.PictureBox68.Image = CType(resources.GetObject("PictureBox68.Image"), System.Drawing.Image)
        Me.PictureBox68.Location = New System.Drawing.Point(93, 234)
        Me.PictureBox68.Name = "PictureBox68"
        Me.PictureBox68.Size = New System.Drawing.Size(21, 23)
        Me.PictureBox68.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.PictureBox68.TabIndex = 2
        Me.PictureBox68.TabStop = False
        '
        'PictureBox105
        '
        Me.PictureBox105.Image = CType(resources.GetObject("PictureBox105.Image"), System.Drawing.Image)
        Me.PictureBox105.Location = New System.Drawing.Point(93, 458)
        Me.PictureBox105.Name = "PictureBox105"
        Me.PictureBox105.Size = New System.Drawing.Size(21, 23)
        Me.PictureBox105.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.PictureBox105.TabIndex = 2
        Me.PictureBox105.TabStop = False
        '
        'PictureBox104
        '
        Me.PictureBox104.Image = CType(resources.GetObject("PictureBox104.Image"), System.Drawing.Image)
        Me.PictureBox104.Location = New System.Drawing.Point(147, 310)
        Me.PictureBox104.Name = "PictureBox104"
        Me.PictureBox104.Size = New System.Drawing.Size(21, 23)
        Me.PictureBox104.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.PictureBox104.TabIndex = 2
        Me.PictureBox104.TabStop = False
        '
        'PictureBox102
        '
        Me.PictureBox102.Image = CType(resources.GetObject("PictureBox102.Image"), System.Drawing.Image)
        Me.PictureBox102.Location = New System.Drawing.Point(93, 384)
        Me.PictureBox102.Name = "PictureBox102"
        Me.PictureBox102.Size = New System.Drawing.Size(21, 23)
        Me.PictureBox102.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.PictureBox102.TabIndex = 2
        Me.PictureBox102.TabStop = False
        '
        'PictureBox99
        '
        Me.PictureBox99.Image = CType(resources.GetObject("PictureBox99.Image"), System.Drawing.Image)
        Me.PictureBox99.Location = New System.Drawing.Point(39, 532)
        Me.PictureBox99.Name = "PictureBox99"
        Me.PictureBox99.Size = New System.Drawing.Size(21, 23)
        Me.PictureBox99.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.PictureBox99.TabIndex = 2
        Me.PictureBox99.TabStop = False
        '
        'PictureBox66
        '
        Me.PictureBox66.Image = CType(resources.GetObject("PictureBox66.Image"), System.Drawing.Image)
        Me.PictureBox66.Location = New System.Drawing.Point(39, 234)
        Me.PictureBox66.Name = "PictureBox66"
        Me.PictureBox66.Size = New System.Drawing.Size(21, 23)
        Me.PictureBox66.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.PictureBox66.TabIndex = 2
        Me.PictureBox66.TabStop = False
        '
        'PictureBox97
        '
        Me.PictureBox97.Image = CType(resources.GetObject("PictureBox97.Image"), System.Drawing.Image)
        Me.PictureBox97.Location = New System.Drawing.Point(39, 458)
        Me.PictureBox97.Name = "PictureBox97"
        Me.PictureBox97.Size = New System.Drawing.Size(21, 23)
        Me.PictureBox97.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.PictureBox97.TabIndex = 2
        Me.PictureBox97.TabStop = False
        '
        'PictureBox96
        '
        Me.PictureBox96.Image = CType(resources.GetObject("PictureBox96.Image"), System.Drawing.Image)
        Me.PictureBox96.Location = New System.Drawing.Point(93, 310)
        Me.PictureBox96.Name = "PictureBox96"
        Me.PictureBox96.Size = New System.Drawing.Size(21, 23)
        Me.PictureBox96.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.PictureBox96.TabIndex = 2
        Me.PictureBox96.TabStop = False
        '
        'PictureBox94
        '
        Me.PictureBox94.Image = CType(resources.GetObject("PictureBox94.Image"), System.Drawing.Image)
        Me.PictureBox94.Location = New System.Drawing.Point(39, 384)
        Me.PictureBox94.Name = "PictureBox94"
        Me.PictureBox94.Size = New System.Drawing.Size(21, 23)
        Me.PictureBox94.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.PictureBox94.TabIndex = 2
        Me.PictureBox94.TabStop = False
        '
        'PictureBox88
        '
        Me.PictureBox88.Image = CType(resources.GetObject("PictureBox88.Image"), System.Drawing.Image)
        Me.PictureBox88.Location = New System.Drawing.Point(39, 310)
        Me.PictureBox88.Name = "PictureBox88"
        Me.PictureBox88.Size = New System.Drawing.Size(21, 23)
        Me.PictureBox88.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.PictureBox88.TabIndex = 2
        Me.PictureBox88.TabStop = False
        '
        'behainggi
        '
        Me.behainggi.Image = Global.WindowsApplication1.My.Resources.Resources.그림1
        Me.behainggi.Location = New System.Drawing.Point(242, 751)
        Me.behainggi.Name = "behainggi"
        Me.behainggi.Size = New System.Drawing.Size(100, 100)
        Me.behainggi.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.behainggi.TabIndex = 0
        Me.behainggi.TabStop = False
        '
        'picbullB
        '
        Me.picbullB.Image = Global.WindowsApplication1.My.Resources.Resources.그림1rf
        Me.picbullB.Location = New System.Drawing.Point(273, 785)
        Me.picbullB.Name = "picbullB"
        Me.picbullB.Size = New System.Drawing.Size(10, 38)
        Me.picbullB.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.picbullB.TabIndex = 1
        Me.picbullB.TabStop = False
        Me.picbullB.Visible = False
        '
        'picbullA
        '
        Me.picbullA.Image = Global.WindowsApplication1.My.Resources.Resources.그림1rf
        Me.picbullA.Location = New System.Drawing.Point(305, 785)
        Me.picbullA.Name = "picbullA"
        Me.picbullA.Size = New System.Drawing.Size(10, 38)
        Me.picbullA.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.picbullA.TabIndex = 1
        Me.picbullA.TabStop = False
        Me.picbullA.Visible = False
        '
        'picbullC
        '
        Me.picbullC.Image = Global.WindowsApplication1.My.Resources.Resources.그림1rf
        Me.picbullC.Location = New System.Drawing.Point(289, 763)
        Me.picbullC.Name = "picbullC"
        Me.picbullC.Size = New System.Drawing.Size(10, 38)
        Me.picbullC.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.picbullC.TabIndex = 1
        Me.picbullC.TabStop = False
        Me.picbullC.Visible = False
        '
        'PictureBox232
        '
        Me.PictureBox232.Image = CType(resources.GetObject("PictureBox232.Image"), System.Drawing.Image)
        Me.PictureBox232.Location = New System.Drawing.Point(551, 263)
        Me.PictureBox232.Name = "PictureBox232"
        Me.PictureBox232.Size = New System.Drawing.Size(21, 23)
        Me.PictureBox232.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.PictureBox232.TabIndex = 2
        Me.PictureBox232.TabStop = False
        '
        'PictureBox233
        '
        Me.PictureBox233.Image = CType(resources.GetObject("PictureBox233.Image"), System.Drawing.Image)
        Me.PictureBox233.Location = New System.Drawing.Point(12, 263)
        Me.PictureBox233.Name = "PictureBox233"
        Me.PictureBox233.Size = New System.Drawing.Size(21, 23)
        Me.PictureBox233.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.PictureBox233.TabIndex = 2
        Me.PictureBox233.TabStop = False
        '
        'PictureBox235
        '
        Me.PictureBox235.Image = CType(resources.GetObject("PictureBox235.Image"), System.Drawing.Image)
        Me.PictureBox235.Location = New System.Drawing.Point(66, 263)
        Me.PictureBox235.Name = "PictureBox235"
        Me.PictureBox235.Size = New System.Drawing.Size(21, 23)
        Me.PictureBox235.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.PictureBox235.TabIndex = 2
        Me.PictureBox235.TabStop = False
        '
        'PictureBox237
        '
        Me.PictureBox237.Image = CType(resources.GetObject("PictureBox237.Image"), System.Drawing.Image)
        Me.PictureBox237.Location = New System.Drawing.Point(120, 263)
        Me.PictureBox237.Name = "PictureBox237"
        Me.PictureBox237.Size = New System.Drawing.Size(21, 23)
        Me.PictureBox237.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.PictureBox237.TabIndex = 2
        Me.PictureBox237.TabStop = False
        '
        'PictureBox239
        '
        Me.PictureBox239.Image = CType(resources.GetObject("PictureBox239.Image"), System.Drawing.Image)
        Me.PictureBox239.Location = New System.Drawing.Point(174, 263)
        Me.PictureBox239.Name = "PictureBox239"
        Me.PictureBox239.Size = New System.Drawing.Size(21, 23)
        Me.PictureBox239.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.PictureBox239.TabIndex = 2
        Me.PictureBox239.TabStop = False
        '
        'PictureBox241
        '
        Me.PictureBox241.Image = CType(resources.GetObject("PictureBox241.Image"), System.Drawing.Image)
        Me.PictureBox241.Location = New System.Drawing.Point(228, 263)
        Me.PictureBox241.Name = "PictureBox241"
        Me.PictureBox241.Size = New System.Drawing.Size(21, 23)
        Me.PictureBox241.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.PictureBox241.TabIndex = 2
        Me.PictureBox241.TabStop = False
        '
        'PictureBox243
        '
        Me.PictureBox243.Image = CType(resources.GetObject("PictureBox243.Image"), System.Drawing.Image)
        Me.PictureBox243.Location = New System.Drawing.Point(282, 263)
        Me.PictureBox243.Name = "PictureBox243"
        Me.PictureBox243.Size = New System.Drawing.Size(21, 23)
        Me.PictureBox243.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.PictureBox243.TabIndex = 2
        Me.PictureBox243.TabStop = False
        '
        'PictureBox245
        '
        Me.PictureBox245.Image = CType(resources.GetObject("PictureBox245.Image"), System.Drawing.Image)
        Me.PictureBox245.Location = New System.Drawing.Point(336, 263)
        Me.PictureBox245.Name = "PictureBox245"
        Me.PictureBox245.Size = New System.Drawing.Size(21, 23)
        Me.PictureBox245.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.PictureBox245.TabIndex = 2
        Me.PictureBox245.TabStop = False
        '
        'PictureBox247
        '
        Me.PictureBox247.Image = CType(resources.GetObject("PictureBox247.Image"), System.Drawing.Image)
        Me.PictureBox247.Location = New System.Drawing.Point(390, 263)
        Me.PictureBox247.Name = "PictureBox247"
        Me.PictureBox247.Size = New System.Drawing.Size(21, 23)
        Me.PictureBox247.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.PictureBox247.TabIndex = 2
        Me.PictureBox247.TabStop = False
        '
        'PictureBox249
        '
        Me.PictureBox249.Image = CType(resources.GetObject("PictureBox249.Image"), System.Drawing.Image)
        Me.PictureBox249.Location = New System.Drawing.Point(444, 263)
        Me.PictureBox249.Name = "PictureBox249"
        Me.PictureBox249.Size = New System.Drawing.Size(21, 23)
        Me.PictureBox249.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.PictureBox249.TabIndex = 2
        Me.PictureBox249.TabStop = False
        '
        'PictureBox251
        '
        Me.PictureBox251.Image = CType(resources.GetObject("PictureBox251.Image"), System.Drawing.Image)
        Me.PictureBox251.Location = New System.Drawing.Point(498, 263)
        Me.PictureBox251.Name = "PictureBox251"
        Me.PictureBox251.Size = New System.Drawing.Size(21, 23)
        Me.PictureBox251.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.PictureBox251.TabIndex = 2
        Me.PictureBox251.TabStop = False
        '
        'PictureBox253
        '
        Me.PictureBox253.Image = CType(resources.GetObject("PictureBox253.Image"), System.Drawing.Image)
        Me.PictureBox253.Location = New System.Drawing.Point(551, 339)
        Me.PictureBox253.Name = "PictureBox253"
        Me.PictureBox253.Size = New System.Drawing.Size(21, 23)
        Me.PictureBox253.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.PictureBox253.TabIndex = 2
        Me.PictureBox253.TabStop = False
        '
        'PictureBox254
        '
        Me.PictureBox254.Image = CType(resources.GetObject("PictureBox254.Image"), System.Drawing.Image)
        Me.PictureBox254.Location = New System.Drawing.Point(12, 339)
        Me.PictureBox254.Name = "PictureBox254"
        Me.PictureBox254.Size = New System.Drawing.Size(21, 23)
        Me.PictureBox254.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.PictureBox254.TabIndex = 2
        Me.PictureBox254.TabStop = False
        '
        'PictureBox256
        '
        Me.PictureBox256.Image = CType(resources.GetObject("PictureBox256.Image"), System.Drawing.Image)
        Me.PictureBox256.Location = New System.Drawing.Point(66, 339)
        Me.PictureBox256.Name = "PictureBox256"
        Me.PictureBox256.Size = New System.Drawing.Size(21, 23)
        Me.PictureBox256.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.PictureBox256.TabIndex = 2
        Me.PictureBox256.TabStop = False
        '
        'PictureBox258
        '
        Me.PictureBox258.Image = CType(resources.GetObject("PictureBox258.Image"), System.Drawing.Image)
        Me.PictureBox258.Location = New System.Drawing.Point(120, 339)
        Me.PictureBox258.Name = "PictureBox258"
        Me.PictureBox258.Size = New System.Drawing.Size(21, 23)
        Me.PictureBox258.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.PictureBox258.TabIndex = 2
        Me.PictureBox258.TabStop = False
        '
        'PictureBox260
        '
        Me.PictureBox260.Image = CType(resources.GetObject("PictureBox260.Image"), System.Drawing.Image)
        Me.PictureBox260.Location = New System.Drawing.Point(174, 339)
        Me.PictureBox260.Name = "PictureBox260"
        Me.PictureBox260.Size = New System.Drawing.Size(21, 23)
        Me.PictureBox260.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.PictureBox260.TabIndex = 2
        Me.PictureBox260.TabStop = False
        '
        'PictureBox262
        '
        Me.PictureBox262.Image = CType(resources.GetObject("PictureBox262.Image"), System.Drawing.Image)
        Me.PictureBox262.Location = New System.Drawing.Point(228, 339)
        Me.PictureBox262.Name = "PictureBox262"
        Me.PictureBox262.Size = New System.Drawing.Size(21, 23)
        Me.PictureBox262.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.PictureBox262.TabIndex = 2
        Me.PictureBox262.TabStop = False
        '
        'PictureBox264
        '
        Me.PictureBox264.Image = CType(resources.GetObject("PictureBox264.Image"), System.Drawing.Image)
        Me.PictureBox264.Location = New System.Drawing.Point(282, 339)
        Me.PictureBox264.Name = "PictureBox264"
        Me.PictureBox264.Size = New System.Drawing.Size(21, 23)
        Me.PictureBox264.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.PictureBox264.TabIndex = 2
        Me.PictureBox264.TabStop = False
        '
        'PictureBox266
        '
        Me.PictureBox266.Image = CType(resources.GetObject("PictureBox266.Image"), System.Drawing.Image)
        Me.PictureBox266.Location = New System.Drawing.Point(336, 339)
        Me.PictureBox266.Name = "PictureBox266"
        Me.PictureBox266.Size = New System.Drawing.Size(21, 23)
        Me.PictureBox266.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.PictureBox266.TabIndex = 2
        Me.PictureBox266.TabStop = False
        '
        'PictureBox268
        '
        Me.PictureBox268.Image = CType(resources.GetObject("PictureBox268.Image"), System.Drawing.Image)
        Me.PictureBox268.Location = New System.Drawing.Point(390, 339)
        Me.PictureBox268.Name = "PictureBox268"
        Me.PictureBox268.Size = New System.Drawing.Size(21, 23)
        Me.PictureBox268.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.PictureBox268.TabIndex = 2
        Me.PictureBox268.TabStop = False
        '
        'PictureBox270
        '
        Me.PictureBox270.Image = CType(resources.GetObject("PictureBox270.Image"), System.Drawing.Image)
        Me.PictureBox270.Location = New System.Drawing.Point(444, 339)
        Me.PictureBox270.Name = "PictureBox270"
        Me.PictureBox270.Size = New System.Drawing.Size(21, 23)
        Me.PictureBox270.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.PictureBox270.TabIndex = 2
        Me.PictureBox270.TabStop = False
        '
        'PictureBox272
        '
        Me.PictureBox272.Image = CType(resources.GetObject("PictureBox272.Image"), System.Drawing.Image)
        Me.PictureBox272.Location = New System.Drawing.Point(498, 339)
        Me.PictureBox272.Name = "PictureBox272"
        Me.PictureBox272.Size = New System.Drawing.Size(21, 23)
        Me.PictureBox272.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.PictureBox272.TabIndex = 2
        Me.PictureBox272.TabStop = False
        '
        'PictureBox274
        '
        Me.PictureBox274.Image = CType(resources.GetObject("PictureBox274.Image"), System.Drawing.Image)
        Me.PictureBox274.Location = New System.Drawing.Point(551, 413)
        Me.PictureBox274.Name = "PictureBox274"
        Me.PictureBox274.Size = New System.Drawing.Size(21, 23)
        Me.PictureBox274.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.PictureBox274.TabIndex = 2
        Me.PictureBox274.TabStop = False
        '
        'PictureBox275
        '
        Me.PictureBox275.Image = CType(resources.GetObject("PictureBox275.Image"), System.Drawing.Image)
        Me.PictureBox275.Location = New System.Drawing.Point(12, 413)
        Me.PictureBox275.Name = "PictureBox275"
        Me.PictureBox275.Size = New System.Drawing.Size(21, 23)
        Me.PictureBox275.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.PictureBox275.TabIndex = 2
        Me.PictureBox275.TabStop = False
        '
        'PictureBox277
        '
        Me.PictureBox277.Image = CType(resources.GetObject("PictureBox277.Image"), System.Drawing.Image)
        Me.PictureBox277.Location = New System.Drawing.Point(66, 413)
        Me.PictureBox277.Name = "PictureBox277"
        Me.PictureBox277.Size = New System.Drawing.Size(21, 23)
        Me.PictureBox277.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.PictureBox277.TabIndex = 2
        Me.PictureBox277.TabStop = False
        '
        'PictureBox279
        '
        Me.PictureBox279.Image = CType(resources.GetObject("PictureBox279.Image"), System.Drawing.Image)
        Me.PictureBox279.Location = New System.Drawing.Point(120, 413)
        Me.PictureBox279.Name = "PictureBox279"
        Me.PictureBox279.Size = New System.Drawing.Size(21, 23)
        Me.PictureBox279.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.PictureBox279.TabIndex = 2
        Me.PictureBox279.TabStop = False
        '
        'PictureBox281
        '
        Me.PictureBox281.Image = CType(resources.GetObject("PictureBox281.Image"), System.Drawing.Image)
        Me.PictureBox281.Location = New System.Drawing.Point(174, 413)
        Me.PictureBox281.Name = "PictureBox281"
        Me.PictureBox281.Size = New System.Drawing.Size(21, 23)
        Me.PictureBox281.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.PictureBox281.TabIndex = 2
        Me.PictureBox281.TabStop = False
        '
        'PictureBox283
        '
        Me.PictureBox283.Image = CType(resources.GetObject("PictureBox283.Image"), System.Drawing.Image)
        Me.PictureBox283.Location = New System.Drawing.Point(228, 413)
        Me.PictureBox283.Name = "PictureBox283"
        Me.PictureBox283.Size = New System.Drawing.Size(21, 23)
        Me.PictureBox283.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.PictureBox283.TabIndex = 2
        Me.PictureBox283.TabStop = False
        '
        'PictureBox285
        '
        Me.PictureBox285.Image = CType(resources.GetObject("PictureBox285.Image"), System.Drawing.Image)
        Me.PictureBox285.Location = New System.Drawing.Point(282, 413)
        Me.PictureBox285.Name = "PictureBox285"
        Me.PictureBox285.Size = New System.Drawing.Size(21, 23)
        Me.PictureBox285.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.PictureBox285.TabIndex = 2
        Me.PictureBox285.TabStop = False
        '
        'PictureBox287
        '
        Me.PictureBox287.Image = CType(resources.GetObject("PictureBox287.Image"), System.Drawing.Image)
        Me.PictureBox287.Location = New System.Drawing.Point(336, 413)
        Me.PictureBox287.Name = "PictureBox287"
        Me.PictureBox287.Size = New System.Drawing.Size(21, 23)
        Me.PictureBox287.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.PictureBox287.TabIndex = 2
        Me.PictureBox287.TabStop = False
        '
        'PictureBox289
        '
        Me.PictureBox289.Image = CType(resources.GetObject("PictureBox289.Image"), System.Drawing.Image)
        Me.PictureBox289.Location = New System.Drawing.Point(390, 413)
        Me.PictureBox289.Name = "PictureBox289"
        Me.PictureBox289.Size = New System.Drawing.Size(21, 23)
        Me.PictureBox289.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.PictureBox289.TabIndex = 2
        Me.PictureBox289.TabStop = False
        '
        'PictureBox291
        '
        Me.PictureBox291.Image = CType(resources.GetObject("PictureBox291.Image"), System.Drawing.Image)
        Me.PictureBox291.Location = New System.Drawing.Point(444, 413)
        Me.PictureBox291.Name = "PictureBox291"
        Me.PictureBox291.Size = New System.Drawing.Size(21, 23)
        Me.PictureBox291.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.PictureBox291.TabIndex = 2
        Me.PictureBox291.TabStop = False
        '
        'PictureBox293
        '
        Me.PictureBox293.Image = CType(resources.GetObject("PictureBox293.Image"), System.Drawing.Image)
        Me.PictureBox293.Location = New System.Drawing.Point(498, 413)
        Me.PictureBox293.Name = "PictureBox293"
        Me.PictureBox293.Size = New System.Drawing.Size(21, 23)
        Me.PictureBox293.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.PictureBox293.TabIndex = 2
        Me.PictureBox293.TabStop = False
        '
        'PictureBox295
        '
        Me.PictureBox295.Image = CType(resources.GetObject("PictureBox295.Image"), System.Drawing.Image)
        Me.PictureBox295.Location = New System.Drawing.Point(551, 487)
        Me.PictureBox295.Name = "PictureBox295"
        Me.PictureBox295.Size = New System.Drawing.Size(21, 23)
        Me.PictureBox295.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.PictureBox295.TabIndex = 2
        Me.PictureBox295.TabStop = False
        '
        'PictureBox296
        '
        Me.PictureBox296.Image = CType(resources.GetObject("PictureBox296.Image"), System.Drawing.Image)
        Me.PictureBox296.Location = New System.Drawing.Point(12, 487)
        Me.PictureBox296.Name = "PictureBox296"
        Me.PictureBox296.Size = New System.Drawing.Size(21, 23)
        Me.PictureBox296.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.PictureBox296.TabIndex = 2
        Me.PictureBox296.TabStop = False
        '
        'PictureBox298
        '
        Me.PictureBox298.Image = CType(resources.GetObject("PictureBox298.Image"), System.Drawing.Image)
        Me.PictureBox298.Location = New System.Drawing.Point(66, 487)
        Me.PictureBox298.Name = "PictureBox298"
        Me.PictureBox298.Size = New System.Drawing.Size(21, 23)
        Me.PictureBox298.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.PictureBox298.TabIndex = 2
        Me.PictureBox298.TabStop = False
        '
        'PictureBox300
        '
        Me.PictureBox300.Image = CType(resources.GetObject("PictureBox300.Image"), System.Drawing.Image)
        Me.PictureBox300.Location = New System.Drawing.Point(120, 487)
        Me.PictureBox300.Name = "PictureBox300"
        Me.PictureBox300.Size = New System.Drawing.Size(21, 23)
        Me.PictureBox300.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.PictureBox300.TabIndex = 2
        Me.PictureBox300.TabStop = False
        '
        'PictureBox302
        '
        Me.PictureBox302.Image = CType(resources.GetObject("PictureBox302.Image"), System.Drawing.Image)
        Me.PictureBox302.Location = New System.Drawing.Point(174, 487)
        Me.PictureBox302.Name = "PictureBox302"
        Me.PictureBox302.Size = New System.Drawing.Size(21, 23)
        Me.PictureBox302.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.PictureBox302.TabIndex = 2
        Me.PictureBox302.TabStop = False
        '
        'PictureBox304
        '
        Me.PictureBox304.Image = CType(resources.GetObject("PictureBox304.Image"), System.Drawing.Image)
        Me.PictureBox304.Location = New System.Drawing.Point(228, 487)
        Me.PictureBox304.Name = "PictureBox304"
        Me.PictureBox304.Size = New System.Drawing.Size(21, 23)
        Me.PictureBox304.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.PictureBox304.TabIndex = 2
        Me.PictureBox304.TabStop = False
        '
        'PictureBox306
        '
        Me.PictureBox306.Image = CType(resources.GetObject("PictureBox306.Image"), System.Drawing.Image)
        Me.PictureBox306.Location = New System.Drawing.Point(282, 487)
        Me.PictureBox306.Name = "PictureBox306"
        Me.PictureBox306.Size = New System.Drawing.Size(21, 23)
        Me.PictureBox306.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.PictureBox306.TabIndex = 2
        Me.PictureBox306.TabStop = False
        '
        'PictureBox308
        '
        Me.PictureBox308.Image = CType(resources.GetObject("PictureBox308.Image"), System.Drawing.Image)
        Me.PictureBox308.Location = New System.Drawing.Point(336, 487)
        Me.PictureBox308.Name = "PictureBox308"
        Me.PictureBox308.Size = New System.Drawing.Size(21, 23)
        Me.PictureBox308.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.PictureBox308.TabIndex = 2
        Me.PictureBox308.TabStop = False
        '
        'PictureBox310
        '
        Me.PictureBox310.Image = CType(resources.GetObject("PictureBox310.Image"), System.Drawing.Image)
        Me.PictureBox310.Location = New System.Drawing.Point(390, 487)
        Me.PictureBox310.Name = "PictureBox310"
        Me.PictureBox310.Size = New System.Drawing.Size(21, 23)
        Me.PictureBox310.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.PictureBox310.TabIndex = 2
        Me.PictureBox310.TabStop = False
        '
        'PictureBox312
        '
        Me.PictureBox312.Image = CType(resources.GetObject("PictureBox312.Image"), System.Drawing.Image)
        Me.PictureBox312.Location = New System.Drawing.Point(444, 487)
        Me.PictureBox312.Name = "PictureBox312"
        Me.PictureBox312.Size = New System.Drawing.Size(21, 23)
        Me.PictureBox312.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.PictureBox312.TabIndex = 2
        Me.PictureBox312.TabStop = False
        '
        'PictureBox314
        '
        Me.PictureBox314.Image = CType(resources.GetObject("PictureBox314.Image"), System.Drawing.Image)
        Me.PictureBox314.Location = New System.Drawing.Point(498, 487)
        Me.PictureBox314.Name = "PictureBox314"
        Me.PictureBox314.Size = New System.Drawing.Size(21, 23)
        Me.PictureBox314.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.PictureBox314.TabIndex = 2
        Me.PictureBox314.TabStop = False
        '
        'PictureBox316
        '
        Me.PictureBox316.Image = CType(resources.GetObject("PictureBox316.Image"), System.Drawing.Image)
        Me.PictureBox316.Location = New System.Drawing.Point(551, 561)
        Me.PictureBox316.Name = "PictureBox316"
        Me.PictureBox316.Size = New System.Drawing.Size(21, 23)
        Me.PictureBox316.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.PictureBox316.TabIndex = 2
        Me.PictureBox316.TabStop = False
        '
        'PictureBox317
        '
        Me.PictureBox317.Image = CType(resources.GetObject("PictureBox317.Image"), System.Drawing.Image)
        Me.PictureBox317.Location = New System.Drawing.Point(12, 561)
        Me.PictureBox317.Name = "PictureBox317"
        Me.PictureBox317.Size = New System.Drawing.Size(21, 23)
        Me.PictureBox317.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.PictureBox317.TabIndex = 2
        Me.PictureBox317.TabStop = False
        '
        'PictureBox319
        '
        Me.PictureBox319.Image = CType(resources.GetObject("PictureBox319.Image"), System.Drawing.Image)
        Me.PictureBox319.Location = New System.Drawing.Point(66, 561)
        Me.PictureBox319.Name = "PictureBox319"
        Me.PictureBox319.Size = New System.Drawing.Size(21, 23)
        Me.PictureBox319.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.PictureBox319.TabIndex = 2
        Me.PictureBox319.TabStop = False
        '
        'PictureBox321
        '
        Me.PictureBox321.Image = CType(resources.GetObject("PictureBox321.Image"), System.Drawing.Image)
        Me.PictureBox321.Location = New System.Drawing.Point(120, 561)
        Me.PictureBox321.Name = "PictureBox321"
        Me.PictureBox321.Size = New System.Drawing.Size(21, 23)
        Me.PictureBox321.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.PictureBox321.TabIndex = 2
        Me.PictureBox321.TabStop = False
        '
        'PictureBox323
        '
        Me.PictureBox323.Image = CType(resources.GetObject("PictureBox323.Image"), System.Drawing.Image)
        Me.PictureBox323.Location = New System.Drawing.Point(174, 561)
        Me.PictureBox323.Name = "PictureBox323"
        Me.PictureBox323.Size = New System.Drawing.Size(21, 23)
        Me.PictureBox323.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.PictureBox323.TabIndex = 2
        Me.PictureBox323.TabStop = False
        '
        'PictureBox325
        '
        Me.PictureBox325.Image = CType(resources.GetObject("PictureBox325.Image"), System.Drawing.Image)
        Me.PictureBox325.Location = New System.Drawing.Point(228, 561)
        Me.PictureBox325.Name = "PictureBox325"
        Me.PictureBox325.Size = New System.Drawing.Size(21, 23)
        Me.PictureBox325.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.PictureBox325.TabIndex = 2
        Me.PictureBox325.TabStop = False
        '
        'PictureBox327
        '
        Me.PictureBox327.Image = CType(resources.GetObject("PictureBox327.Image"), System.Drawing.Image)
        Me.PictureBox327.Location = New System.Drawing.Point(282, 561)
        Me.PictureBox327.Name = "PictureBox327"
        Me.PictureBox327.Size = New System.Drawing.Size(21, 23)
        Me.PictureBox327.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.PictureBox327.TabIndex = 2
        Me.PictureBox327.TabStop = False
        '
        'PictureBox329
        '
        Me.PictureBox329.Image = CType(resources.GetObject("PictureBox329.Image"), System.Drawing.Image)
        Me.PictureBox329.Location = New System.Drawing.Point(336, 561)
        Me.PictureBox329.Name = "PictureBox329"
        Me.PictureBox329.Size = New System.Drawing.Size(21, 23)
        Me.PictureBox329.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.PictureBox329.TabIndex = 2
        Me.PictureBox329.TabStop = False
        '
        'PictureBox331
        '
        Me.PictureBox331.Image = CType(resources.GetObject("PictureBox331.Image"), System.Drawing.Image)
        Me.PictureBox331.Location = New System.Drawing.Point(390, 561)
        Me.PictureBox331.Name = "PictureBox331"
        Me.PictureBox331.Size = New System.Drawing.Size(21, 23)
        Me.PictureBox331.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.PictureBox331.TabIndex = 2
        Me.PictureBox331.TabStop = False
        '
        'PictureBox333
        '
        Me.PictureBox333.Image = CType(resources.GetObject("PictureBox333.Image"), System.Drawing.Image)
        Me.PictureBox333.Location = New System.Drawing.Point(444, 561)
        Me.PictureBox333.Name = "PictureBox333"
        Me.PictureBox333.Size = New System.Drawing.Size(21, 23)
        Me.PictureBox333.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.PictureBox333.TabIndex = 2
        Me.PictureBox333.TabStop = False
        '
        'PictureBox335
        '
        Me.PictureBox335.Image = CType(resources.GetObject("PictureBox335.Image"), System.Drawing.Image)
        Me.PictureBox335.Location = New System.Drawing.Point(498, 561)
        Me.PictureBox335.Name = "PictureBox335"
        Me.PictureBox335.Size = New System.Drawing.Size(21, 23)
        Me.PictureBox335.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.PictureBox335.TabIndex = 2
        Me.PictureBox335.TabStop = False
        '
        'PictureBox2
        '
        Me.PictureBox2.Image = CType(resources.GetObject("PictureBox2.Image"), System.Drawing.Image)
        Me.PictureBox2.Location = New System.Drawing.Point(227, 32)
        Me.PictureBox2.Name = "PictureBox2"
        Me.PictureBox2.Size = New System.Drawing.Size(130, 130)
        Me.PictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.PictureBox2.TabIndex = 2
        Me.PictureBox2.TabStop = False
        '
        'ddd
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(7.0!, 12.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(584, 862)
        Me.Controls.Add(Me.PictureBox168)
        Me.Controls.Add(Me.PictureBox84)
        Me.Controls.Add(Me.PictureBox167)
        Me.Controls.Add(Me.PictureBox166)
        Me.Controls.Add(Me.PictureBox165)
        Me.Controls.Add(Me.PictureBox335)
        Me.Controls.Add(Me.PictureBox314)
        Me.Controls.Add(Me.PictureBox293)
        Me.Controls.Add(Me.PictureBox272)
        Me.Controls.Add(Me.PictureBox251)
        Me.Controls.Add(Me.PictureBox160)
        Me.Controls.Add(Me.PictureBox159)
        Me.Controls.Add(Me.PictureBox82)
        Me.Controls.Add(Me.PictureBox158)
        Me.Controls.Add(Me.PictureBox157)
        Me.Controls.Add(Me.PictureBox333)
        Me.Controls.Add(Me.PictureBox312)
        Me.Controls.Add(Me.PictureBox291)
        Me.Controls.Add(Me.PictureBox270)
        Me.Controls.Add(Me.PictureBox249)
        Me.Controls.Add(Me.PictureBox152)
        Me.Controls.Add(Me.PictureBox151)
        Me.Controls.Add(Me.PictureBox80)
        Me.Controls.Add(Me.PictureBox150)
        Me.Controls.Add(Me.PictureBox149)
        Me.Controls.Add(Me.PictureBox331)
        Me.Controls.Add(Me.PictureBox310)
        Me.Controls.Add(Me.PictureBox289)
        Me.Controls.Add(Me.PictureBox268)
        Me.Controls.Add(Me.PictureBox247)
        Me.Controls.Add(Me.PictureBox144)
        Me.Controls.Add(Me.PictureBox143)
        Me.Controls.Add(Me.PictureBox78)
        Me.Controls.Add(Me.PictureBox142)
        Me.Controls.Add(Me.PictureBox141)
        Me.Controls.Add(Me.PictureBox329)
        Me.Controls.Add(Me.PictureBox308)
        Me.Controls.Add(Me.PictureBox287)
        Me.Controls.Add(Me.PictureBox266)
        Me.Controls.Add(Me.PictureBox245)
        Me.Controls.Add(Me.PictureBox136)
        Me.Controls.Add(Me.PictureBox76)
        Me.Controls.Add(Me.PictureBox134)
        Me.Controls.Add(Me.PictureBox132)
        Me.Controls.Add(Me.PictureBox131)
        Me.Controls.Add(Me.PictureBox74)
        Me.Controls.Add(Me.PictureBox129)
        Me.Controls.Add(Me.PictureBox327)
        Me.Controls.Add(Me.PictureBox306)
        Me.Controls.Add(Me.PictureBox285)
        Me.Controls.Add(Me.PictureBox264)
        Me.Controls.Add(Me.PictureBox243)
        Me.Controls.Add(Me.PictureBox128)
        Me.Controls.Add(Me.PictureBox126)
        Me.Controls.Add(Me.PictureBox123)
        Me.Controls.Add(Me.PictureBox72)
        Me.Controls.Add(Me.PictureBox121)
        Me.Controls.Add(Me.PictureBox325)
        Me.Controls.Add(Me.PictureBox304)
        Me.Controls.Add(Me.PictureBox283)
        Me.Controls.Add(Me.PictureBox262)
        Me.Controls.Add(Me.PictureBox241)
        Me.Controls.Add(Me.PictureBox120)
        Me.Controls.Add(Me.PictureBox118)
        Me.Controls.Add(Me.PictureBox115)
        Me.Controls.Add(Me.PictureBox70)
        Me.Controls.Add(Me.PictureBox113)
        Me.Controls.Add(Me.PictureBox323)
        Me.Controls.Add(Me.PictureBox302)
        Me.Controls.Add(Me.PictureBox281)
        Me.Controls.Add(Me.PictureBox260)
        Me.Controls.Add(Me.PictureBox239)
        Me.Controls.Add(Me.PictureBox112)
        Me.Controls.Add(Me.PictureBox110)
        Me.Controls.Add(Me.PictureBox107)
        Me.Controls.Add(Me.PictureBox68)
        Me.Controls.Add(Me.PictureBox105)
        Me.Controls.Add(Me.PictureBox321)
        Me.Controls.Add(Me.PictureBox300)
        Me.Controls.Add(Me.PictureBox279)
        Me.Controls.Add(Me.PictureBox258)
        Me.Controls.Add(Me.PictureBox237)
        Me.Controls.Add(Me.PictureBox104)
        Me.Controls.Add(Me.PictureBox102)
        Me.Controls.Add(Me.PictureBox99)
        Me.Controls.Add(Me.PictureBox66)
        Me.Controls.Add(Me.PictureBox97)
        Me.Controls.Add(Me.PictureBox319)
        Me.Controls.Add(Me.PictureBox298)
        Me.Controls.Add(Me.PictureBox277)
        Me.Controls.Add(Me.PictureBox256)
        Me.Controls.Add(Me.PictureBox235)
        Me.Controls.Add(Me.PictureBox96)
        Me.Controls.Add(Me.PictureBox94)
        Me.Controls.Add(Me.PictureBox317)
        Me.Controls.Add(Me.PictureBox296)
        Me.Controls.Add(Me.PictureBox275)
        Me.Controls.Add(Me.PictureBox254)
        Me.Controls.Add(Me.PictureBox233)
        Me.Controls.Add(Me.PictureBox88)
        Me.Controls.Add(Me.PictureBox316)
        Me.Controls.Add(Me.PictureBox295)
        Me.Controls.Add(Me.PictureBox274)
        Me.Controls.Add(Me.PictureBox253)
        Me.Controls.Add(Me.PictureBox232)
        Me.Controls.Add(Me.PictureBox2)
        Me.Controls.Add(Me.behainggi)
        Me.Controls.Add(Me.picbullB)
        Me.Controls.Add(Me.picbullA)
        Me.Controls.Add(Me.picbullC)
        Me.MaximizeBox = False
        Me.MaximumSize = New System.Drawing.Size(600, 900)
        Me.MinimizeBox = False
        Me.MinimumSize = New System.Drawing.Size(600, 900)
        Me.Name = "ddd"
        Me.Text = "Game"
        CType(Me.PictureBox168, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox84, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox167, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox166, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox165, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox160, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox159, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox82, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox158, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox157, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox152, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox151, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox80, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox150, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox149, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox144, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox143, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox78, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox142, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox141, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox136, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox76, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox134, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox132, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox131, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox74, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox129, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox128, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox126, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox123, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox72, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox121, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox120, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox118, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox115, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox70, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox113, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox112, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox110, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox107, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox68, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox105, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox104, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox102, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox99, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox66, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox97, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox96, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox94, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox88, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.behainggi, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picbullB, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picbullA, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picbullC, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox232, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox233, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox235, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox237, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox239, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox241, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox243, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox245, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox247, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox249, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox251, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox253, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox254, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox256, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox258, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox260, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox262, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox264, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox266, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox268, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox270, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox272, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox274, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox275, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox277, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox279, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox281, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox283, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox285, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox287, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox289, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox291, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox293, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox295, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox296, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox298, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox300, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox302, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox304, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox306, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox308, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox310, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox312, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox314, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox316, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox317, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox319, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox321, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox323, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox325, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox327, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox329, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox331, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox333, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox335, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox2, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents behainggi As System.Windows.Forms.PictureBox
    Friend WithEvents picbullC As System.Windows.Forms.PictureBox
    Friend WithEvents picbullA As System.Windows.Forms.PictureBox
    Friend WithEvents picbullB As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox66 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox68 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox70 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox72 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox74 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox76 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox78 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox80 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox82 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox84 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox88 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox94 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox96 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox97 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox99 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox102 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox104 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox105 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox107 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox110 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox112 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox113 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox115 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox118 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox120 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox121 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox123 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox126 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox128 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox129 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox131 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox132 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox134 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox136 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox141 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox142 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox143 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox144 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox149 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox150 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox151 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox152 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox157 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox158 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox159 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox160 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox165 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox166 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox167 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox168 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox232 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox233 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox235 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox237 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox239 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox241 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox243 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox245 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox247 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox249 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox251 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox253 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox254 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox256 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox258 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox260 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox262 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox264 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox266 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox268 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox270 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox272 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox274 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox275 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox277 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox279 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox281 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox283 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox285 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox287 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox289 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox291 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox293 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox295 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox296 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox298 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox300 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox302 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox304 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox306 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox308 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox310 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox312 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox314 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox316 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox317 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox319 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox321 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox323 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox325 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox327 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox329 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox331 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox333 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox335 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox2 As System.Windows.Forms.PictureBox

End Class
