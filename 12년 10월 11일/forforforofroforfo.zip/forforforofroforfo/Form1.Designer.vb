﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class ddd
    Inherits System.Windows.Forms.Form

    'Form은 Dispose를 재정의하여 구성 요소 목록을 정리합니다.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Windows Form 디자이너에 필요합니다.
    Private components As System.ComponentModel.IContainer

    '참고: 다음 프로시저는 Windows Form 디자이너에 필요합니다.
    '수정하려면 Windows Form 디자이너를 사용하십시오.  
    '코드 편집기를 사용하여 수정하지 마십시오.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(ddd))
        Me.o94 = New System.Windows.Forms.PictureBox()
        Me.o10 = New System.Windows.Forms.PictureBox()
        Me.o73 = New System.Windows.Forms.PictureBox()
        Me.o52 = New System.Windows.Forms.PictureBox()
        Me.o31 = New System.Windows.Forms.PictureBox()
        Me.o93 = New System.Windows.Forms.PictureBox()
        Me.o72 = New System.Windows.Forms.PictureBox()
        Me.o9 = New System.Windows.Forms.PictureBox()
        Me.o51 = New System.Windows.Forms.PictureBox()
        Me.o30 = New System.Windows.Forms.PictureBox()
        Me.o92 = New System.Windows.Forms.PictureBox()
        Me.o71 = New System.Windows.Forms.PictureBox()
        Me.o8 = New System.Windows.Forms.PictureBox()
        Me.o50 = New System.Windows.Forms.PictureBox()
        Me.o29 = New System.Windows.Forms.PictureBox()
        Me.o91 = New System.Windows.Forms.PictureBox()
        Me.o70 = New System.Windows.Forms.PictureBox()
        Me.o7 = New System.Windows.Forms.PictureBox()
        Me.o49 = New System.Windows.Forms.PictureBox()
        Me.o28 = New System.Windows.Forms.PictureBox()
        Me.o90 = New System.Windows.Forms.PictureBox()
        Me.o6 = New System.Windows.Forms.PictureBox()
        Me.o69 = New System.Windows.Forms.PictureBox()
        Me.o48 = New System.Windows.Forms.PictureBox()
        Me.o89 = New System.Windows.Forms.PictureBox()
        Me.o5 = New System.Windows.Forms.PictureBox()
        Me.o68 = New System.Windows.Forms.PictureBox()
        Me.o27 = New System.Windows.Forms.PictureBox()
        Me.o47 = New System.Windows.Forms.PictureBox()
        Me.o88 = New System.Windows.Forms.PictureBox()
        Me.o4 = New System.Windows.Forms.PictureBox()
        Me.o67 = New System.Windows.Forms.PictureBox()
        Me.o26 = New System.Windows.Forms.PictureBox()
        Me.o46 = New System.Windows.Forms.PictureBox()
        Me.o87 = New System.Windows.Forms.PictureBox()
        Me.o3 = New System.Windows.Forms.PictureBox()
        Me.o66 = New System.Windows.Forms.PictureBox()
        Me.o25 = New System.Windows.Forms.PictureBox()
        Me.o45 = New System.Windows.Forms.PictureBox()
        Me.o86 = New System.Windows.Forms.PictureBox()
        Me.o2 = New System.Windows.Forms.PictureBox()
        Me.o65 = New System.Windows.Forms.PictureBox()
        Me.o24 = New System.Windows.Forms.PictureBox()
        Me.o44 = New System.Windows.Forms.PictureBox()
        Me.o85 = New System.Windows.Forms.PictureBox()
        Me.o1 = New System.Windows.Forms.PictureBox()
        Me.o64 = New System.Windows.Forms.PictureBox()
        Me.o23 = New System.Windows.Forms.PictureBox()
        Me.o43 = New System.Windows.Forms.PictureBox()
        Me.o22 = New System.Windows.Forms.PictureBox()
        Me.behainggi = New System.Windows.Forms.PictureBox()
        Me.picbullB = New System.Windows.Forms.PictureBox()
        Me.picbullA = New System.Windows.Forms.PictureBox()
        Me.picbullC = New System.Windows.Forms.PictureBox()
        Me.o21 = New System.Windows.Forms.PictureBox()
        Me.o11 = New System.Windows.Forms.PictureBox()
        Me.o12 = New System.Windows.Forms.PictureBox()
        Me.o13 = New System.Windows.Forms.PictureBox()
        Me.o14 = New System.Windows.Forms.PictureBox()
        Me.o15 = New System.Windows.Forms.PictureBox()
        Me.o16 = New System.Windows.Forms.PictureBox()
        Me.o17 = New System.Windows.Forms.PictureBox()
        Me.o18 = New System.Windows.Forms.PictureBox()
        Me.o19 = New System.Windows.Forms.PictureBox()
        Me.o20 = New System.Windows.Forms.PictureBox()
        Me.o42 = New System.Windows.Forms.PictureBox()
        Me.o32 = New System.Windows.Forms.PictureBox()
        Me.o33 = New System.Windows.Forms.PictureBox()
        Me.o34 = New System.Windows.Forms.PictureBox()
        Me.o35 = New System.Windows.Forms.PictureBox()
        Me.o36 = New System.Windows.Forms.PictureBox()
        Me.o37 = New System.Windows.Forms.PictureBox()
        Me.o38 = New System.Windows.Forms.PictureBox()
        Me.o39 = New System.Windows.Forms.PictureBox()
        Me.o40 = New System.Windows.Forms.PictureBox()
        Me.o41 = New System.Windows.Forms.PictureBox()
        Me.o63 = New System.Windows.Forms.PictureBox()
        Me.o53 = New System.Windows.Forms.PictureBox()
        Me.o54 = New System.Windows.Forms.PictureBox()
        Me.o55 = New System.Windows.Forms.PictureBox()
        Me.o56 = New System.Windows.Forms.PictureBox()
        Me.o57 = New System.Windows.Forms.PictureBox()
        Me.o58 = New System.Windows.Forms.PictureBox()
        Me.o59 = New System.Windows.Forms.PictureBox()
        Me.o60 = New System.Windows.Forms.PictureBox()
        Me.o61 = New System.Windows.Forms.PictureBox()
        Me.o62 = New System.Windows.Forms.PictureBox()
        Me.o84 = New System.Windows.Forms.PictureBox()
        Me.o74 = New System.Windows.Forms.PictureBox()
        Me.o75 = New System.Windows.Forms.PictureBox()
        Me.o76 = New System.Windows.Forms.PictureBox()
        Me.o77 = New System.Windows.Forms.PictureBox()
        Me.o78 = New System.Windows.Forms.PictureBox()
        Me.o79 = New System.Windows.Forms.PictureBox()
        Me.o80 = New System.Windows.Forms.PictureBox()
        Me.o81 = New System.Windows.Forms.PictureBox()
        Me.o82 = New System.Windows.Forms.PictureBox()
        Me.o83 = New System.Windows.Forms.PictureBox()
        Me.o105 = New System.Windows.Forms.PictureBox()
        Me.o95 = New System.Windows.Forms.PictureBox()
        Me.o96 = New System.Windows.Forms.PictureBox()
        Me.o97 = New System.Windows.Forms.PictureBox()
        Me.o98 = New System.Windows.Forms.PictureBox()
        Me.o99 = New System.Windows.Forms.PictureBox()
        Me.o100 = New System.Windows.Forms.PictureBox()
        Me.o101 = New System.Windows.Forms.PictureBox()
        Me.o102 = New System.Windows.Forms.PictureBox()
        Me.o103 = New System.Windows.Forms.PictureBox()
        Me.o104 = New System.Windows.Forms.PictureBox()
        Me.oBoss = New System.Windows.Forms.PictureBox()
        CType(Me.o94, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.o10, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.o73, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.o52, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.o31, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.o93, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.o72, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.o9, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.o51, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.o30, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.o92, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.o71, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.o8, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.o50, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.o29, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.o91, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.o70, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.o7, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.o49, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.o28, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.o90, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.o6, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.o69, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.o48, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.o89, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.o5, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.o68, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.o27, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.o47, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.o88, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.o4, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.o67, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.o26, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.o46, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.o87, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.o3, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.o66, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.o25, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.o45, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.o86, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.o2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.o65, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.o24, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.o44, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.o85, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.o1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.o64, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.o23, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.o43, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.o22, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.behainggi, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picbullB, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picbullA, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picbullC, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.o21, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.o11, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.o12, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.o13, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.o14, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.o15, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.o16, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.o17, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.o18, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.o19, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.o20, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.o42, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.o32, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.o33, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.o34, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.o35, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.o36, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.o37, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.o38, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.o39, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.o40, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.o41, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.o63, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.o53, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.o54, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.o55, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.o56, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.o57, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.o58, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.o59, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.o60, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.o61, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.o62, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.o84, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.o74, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.o75, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.o76, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.o77, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.o78, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.o79, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.o80, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.o81, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.o82, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.o83, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.o105, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.o95, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.o96, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.o97, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.o98, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.o99, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.o100, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.o101, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.o102, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.o103, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.o104, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.oBoss, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'o94
        '
        Me.o94.Image = CType(resources.GetObject("o94.Image"), System.Drawing.Image)
        Me.o94.Location = New System.Drawing.Point(524, 532)
        Me.o94.Name = "o94"
        Me.o94.Size = New System.Drawing.Size(21, 23)
        Me.o94.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.o94.TabIndex = 2
        Me.o94.TabStop = False
        '
        'o10
        '
        Me.o10.Image = CType(resources.GetObject("o10.Image"), System.Drawing.Image)
        Me.o10.Location = New System.Drawing.Point(524, 234)
        Me.o10.Name = "o10"
        Me.o10.Size = New System.Drawing.Size(21, 23)
        Me.o10.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.o10.TabIndex = 2
        Me.o10.TabStop = False
        '
        'o73
        '
        Me.o73.Image = CType(resources.GetObject("o73.Image"), System.Drawing.Image)
        Me.o73.Location = New System.Drawing.Point(524, 458)
        Me.o73.Name = "o73"
        Me.o73.Size = New System.Drawing.Size(21, 23)
        Me.o73.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.o73.TabIndex = 2
        Me.o73.TabStop = False
        '
        'o52
        '
        Me.o52.Image = CType(resources.GetObject("o52.Image"), System.Drawing.Image)
        Me.o52.Location = New System.Drawing.Point(524, 384)
        Me.o52.Name = "o52"
        Me.o52.Size = New System.Drawing.Size(21, 23)
        Me.o52.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.o52.TabIndex = 2
        Me.o52.TabStop = False
        '
        'o31
        '
        Me.o31.Image = CType(resources.GetObject("o31.Image"), System.Drawing.Image)
        Me.o31.Location = New System.Drawing.Point(524, 310)
        Me.o31.Name = "o31"
        Me.o31.Size = New System.Drawing.Size(21, 23)
        Me.o31.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.o31.TabIndex = 2
        Me.o31.TabStop = False
        '
        'o93
        '
        Me.o93.Image = CType(resources.GetObject("o93.Image"), System.Drawing.Image)
        Me.o93.Location = New System.Drawing.Point(471, 532)
        Me.o93.Name = "o93"
        Me.o93.Size = New System.Drawing.Size(21, 23)
        Me.o93.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.o93.TabIndex = 2
        Me.o93.TabStop = False
        '
        'o72
        '
        Me.o72.Image = CType(resources.GetObject("o72.Image"), System.Drawing.Image)
        Me.o72.Location = New System.Drawing.Point(471, 458)
        Me.o72.Name = "o72"
        Me.o72.Size = New System.Drawing.Size(21, 23)
        Me.o72.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.o72.TabIndex = 2
        Me.o72.TabStop = False
        '
        'o9
        '
        Me.o9.Image = CType(resources.GetObject("o9.Image"), System.Drawing.Image)
        Me.o9.Location = New System.Drawing.Point(471, 234)
        Me.o9.Name = "o9"
        Me.o9.Size = New System.Drawing.Size(21, 23)
        Me.o9.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.o9.TabIndex = 2
        Me.o9.TabStop = False
        '
        'o51
        '
        Me.o51.Image = CType(resources.GetObject("o51.Image"), System.Drawing.Image)
        Me.o51.Location = New System.Drawing.Point(471, 384)
        Me.o51.Name = "o51"
        Me.o51.Size = New System.Drawing.Size(21, 23)
        Me.o51.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.o51.TabIndex = 2
        Me.o51.TabStop = False
        '
        'o30
        '
        Me.o30.Image = CType(resources.GetObject("o30.Image"), System.Drawing.Image)
        Me.o30.Location = New System.Drawing.Point(471, 310)
        Me.o30.Name = "o30"
        Me.o30.Size = New System.Drawing.Size(21, 23)
        Me.o30.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.o30.TabIndex = 2
        Me.o30.TabStop = False
        '
        'o92
        '
        Me.o92.Image = CType(resources.GetObject("o92.Image"), System.Drawing.Image)
        Me.o92.Location = New System.Drawing.Point(417, 532)
        Me.o92.Name = "o92"
        Me.o92.Size = New System.Drawing.Size(21, 23)
        Me.o92.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.o92.TabIndex = 2
        Me.o92.TabStop = False
        '
        'o71
        '
        Me.o71.Image = CType(resources.GetObject("o71.Image"), System.Drawing.Image)
        Me.o71.Location = New System.Drawing.Point(417, 458)
        Me.o71.Name = "o71"
        Me.o71.Size = New System.Drawing.Size(21, 23)
        Me.o71.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.o71.TabIndex = 2
        Me.o71.TabStop = False
        '
        'o8
        '
        Me.o8.Image = CType(resources.GetObject("o8.Image"), System.Drawing.Image)
        Me.o8.Location = New System.Drawing.Point(417, 234)
        Me.o8.Name = "o8"
        Me.o8.Size = New System.Drawing.Size(21, 23)
        Me.o8.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.o8.TabIndex = 2
        Me.o8.TabStop = False
        '
        'o50
        '
        Me.o50.Image = CType(resources.GetObject("o50.Image"), System.Drawing.Image)
        Me.o50.Location = New System.Drawing.Point(417, 384)
        Me.o50.Name = "o50"
        Me.o50.Size = New System.Drawing.Size(21, 23)
        Me.o50.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.o50.TabIndex = 2
        Me.o50.TabStop = False
        '
        'o29
        '
        Me.o29.Image = CType(resources.GetObject("o29.Image"), System.Drawing.Image)
        Me.o29.Location = New System.Drawing.Point(417, 310)
        Me.o29.Name = "o29"
        Me.o29.Size = New System.Drawing.Size(21, 23)
        Me.o29.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.o29.TabIndex = 2
        Me.o29.TabStop = False
        '
        'o91
        '
        Me.o91.Image = CType(resources.GetObject("o91.Image"), System.Drawing.Image)
        Me.o91.Location = New System.Drawing.Point(363, 532)
        Me.o91.Name = "o91"
        Me.o91.Size = New System.Drawing.Size(21, 23)
        Me.o91.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.o91.TabIndex = 2
        Me.o91.TabStop = False
        '
        'o70
        '
        Me.o70.Image = CType(resources.GetObject("o70.Image"), System.Drawing.Image)
        Me.o70.Location = New System.Drawing.Point(363, 458)
        Me.o70.Name = "o70"
        Me.o70.Size = New System.Drawing.Size(21, 23)
        Me.o70.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.o70.TabIndex = 2
        Me.o70.TabStop = False
        '
        'o7
        '
        Me.o7.Image = CType(resources.GetObject("o7.Image"), System.Drawing.Image)
        Me.o7.Location = New System.Drawing.Point(363, 234)
        Me.o7.Name = "o7"
        Me.o7.Size = New System.Drawing.Size(21, 23)
        Me.o7.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.o7.TabIndex = 2
        Me.o7.TabStop = False
        '
        'o49
        '
        Me.o49.Image = CType(resources.GetObject("o49.Image"), System.Drawing.Image)
        Me.o49.Location = New System.Drawing.Point(363, 384)
        Me.o49.Name = "o49"
        Me.o49.Size = New System.Drawing.Size(21, 23)
        Me.o49.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.o49.TabIndex = 2
        Me.o49.TabStop = False
        '
        'o28
        '
        Me.o28.Image = CType(resources.GetObject("o28.Image"), System.Drawing.Image)
        Me.o28.Location = New System.Drawing.Point(363, 310)
        Me.o28.Name = "o28"
        Me.o28.Size = New System.Drawing.Size(21, 23)
        Me.o28.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.o28.TabIndex = 2
        Me.o28.TabStop = False
        '
        'o90
        '
        Me.o90.Image = CType(resources.GetObject("o90.Image"), System.Drawing.Image)
        Me.o90.Location = New System.Drawing.Point(309, 532)
        Me.o90.Name = "o90"
        Me.o90.Size = New System.Drawing.Size(21, 23)
        Me.o90.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.o90.TabIndex = 2
        Me.o90.TabStop = False
        '
        'o6
        '
        Me.o6.Image = CType(resources.GetObject("o6.Image"), System.Drawing.Image)
        Me.o6.Location = New System.Drawing.Point(309, 234)
        Me.o6.Name = "o6"
        Me.o6.Size = New System.Drawing.Size(21, 23)
        Me.o6.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.o6.TabIndex = 2
        Me.o6.TabStop = False
        '
        'o69
        '
        Me.o69.Image = CType(resources.GetObject("o69.Image"), System.Drawing.Image)
        Me.o69.Location = New System.Drawing.Point(309, 458)
        Me.o69.Name = "o69"
        Me.o69.Size = New System.Drawing.Size(21, 23)
        Me.o69.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.o69.TabIndex = 2
        Me.o69.TabStop = False
        '
        'o48
        '
        Me.o48.Image = CType(resources.GetObject("o48.Image"), System.Drawing.Image)
        Me.o48.Location = New System.Drawing.Point(309, 384)
        Me.o48.Name = "o48"
        Me.o48.Size = New System.Drawing.Size(21, 23)
        Me.o48.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.o48.TabIndex = 2
        Me.o48.TabStop = False
        '
        'o89
        '
        Me.o89.Image = CType(resources.GetObject("o89.Image"), System.Drawing.Image)
        Me.o89.Location = New System.Drawing.Point(255, 532)
        Me.o89.Name = "o89"
        Me.o89.Size = New System.Drawing.Size(21, 23)
        Me.o89.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.o89.TabIndex = 2
        Me.o89.TabStop = False
        '
        'o5
        '
        Me.o5.Image = CType(resources.GetObject("o5.Image"), System.Drawing.Image)
        Me.o5.Location = New System.Drawing.Point(255, 234)
        Me.o5.Name = "o5"
        Me.o5.Size = New System.Drawing.Size(21, 23)
        Me.o5.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.o5.TabIndex = 2
        Me.o5.TabStop = False
        '
        'o68
        '
        Me.o68.Image = CType(resources.GetObject("o68.Image"), System.Drawing.Image)
        Me.o68.Location = New System.Drawing.Point(255, 458)
        Me.o68.Name = "o68"
        Me.o68.Size = New System.Drawing.Size(21, 23)
        Me.o68.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.o68.TabIndex = 2
        Me.o68.TabStop = False
        '
        'o27
        '
        Me.o27.Image = CType(resources.GetObject("o27.Image"), System.Drawing.Image)
        Me.o27.Location = New System.Drawing.Point(309, 310)
        Me.o27.Name = "o27"
        Me.o27.Size = New System.Drawing.Size(21, 23)
        Me.o27.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.o27.TabIndex = 2
        Me.o27.TabStop = False
        '
        'o47
        '
        Me.o47.Image = CType(resources.GetObject("o47.Image"), System.Drawing.Image)
        Me.o47.Location = New System.Drawing.Point(255, 384)
        Me.o47.Name = "o47"
        Me.o47.Size = New System.Drawing.Size(21, 23)
        Me.o47.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.o47.TabIndex = 2
        Me.o47.TabStop = False
        '
        'o88
        '
        Me.o88.Image = CType(resources.GetObject("o88.Image"), System.Drawing.Image)
        Me.o88.Location = New System.Drawing.Point(201, 532)
        Me.o88.Name = "o88"
        Me.o88.Size = New System.Drawing.Size(21, 23)
        Me.o88.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.o88.TabIndex = 2
        Me.o88.TabStop = False
        '
        'o4
        '
        Me.o4.Image = CType(resources.GetObject("o4.Image"), System.Drawing.Image)
        Me.o4.Location = New System.Drawing.Point(201, 234)
        Me.o4.Name = "o4"
        Me.o4.Size = New System.Drawing.Size(21, 23)
        Me.o4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.o4.TabIndex = 2
        Me.o4.TabStop = False
        '
        'o67
        '
        Me.o67.Image = CType(resources.GetObject("o67.Image"), System.Drawing.Image)
        Me.o67.Location = New System.Drawing.Point(201, 458)
        Me.o67.Name = "o67"
        Me.o67.Size = New System.Drawing.Size(21, 23)
        Me.o67.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.o67.TabIndex = 2
        Me.o67.TabStop = False
        '
        'o26
        '
        Me.o26.Image = CType(resources.GetObject("o26.Image"), System.Drawing.Image)
        Me.o26.Location = New System.Drawing.Point(255, 310)
        Me.o26.Name = "o26"
        Me.o26.Size = New System.Drawing.Size(21, 23)
        Me.o26.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.o26.TabIndex = 2
        Me.o26.TabStop = False
        '
        'o46
        '
        Me.o46.Image = CType(resources.GetObject("o46.Image"), System.Drawing.Image)
        Me.o46.Location = New System.Drawing.Point(201, 384)
        Me.o46.Name = "o46"
        Me.o46.Size = New System.Drawing.Size(21, 23)
        Me.o46.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.o46.TabIndex = 2
        Me.o46.TabStop = False
        '
        'o87
        '
        Me.o87.Image = CType(resources.GetObject("o87.Image"), System.Drawing.Image)
        Me.o87.Location = New System.Drawing.Point(147, 532)
        Me.o87.Name = "o87"
        Me.o87.Size = New System.Drawing.Size(21, 23)
        Me.o87.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.o87.TabIndex = 2
        Me.o87.TabStop = False
        '
        'o3
        '
        Me.o3.Image = CType(resources.GetObject("o3.Image"), System.Drawing.Image)
        Me.o3.Location = New System.Drawing.Point(147, 234)
        Me.o3.Name = "o3"
        Me.o3.Size = New System.Drawing.Size(21, 23)
        Me.o3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.o3.TabIndex = 2
        Me.o3.TabStop = False
        '
        'o66
        '
        Me.o66.Image = CType(resources.GetObject("o66.Image"), System.Drawing.Image)
        Me.o66.Location = New System.Drawing.Point(147, 458)
        Me.o66.Name = "o66"
        Me.o66.Size = New System.Drawing.Size(21, 23)
        Me.o66.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.o66.TabIndex = 2
        Me.o66.TabStop = False
        '
        'o25
        '
        Me.o25.Image = CType(resources.GetObject("o25.Image"), System.Drawing.Image)
        Me.o25.Location = New System.Drawing.Point(201, 310)
        Me.o25.Name = "o25"
        Me.o25.Size = New System.Drawing.Size(21, 23)
        Me.o25.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.o25.TabIndex = 2
        Me.o25.TabStop = False
        '
        'o45
        '
        Me.o45.Image = CType(resources.GetObject("o45.Image"), System.Drawing.Image)
        Me.o45.Location = New System.Drawing.Point(147, 384)
        Me.o45.Name = "o45"
        Me.o45.Size = New System.Drawing.Size(21, 23)
        Me.o45.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.o45.TabIndex = 2
        Me.o45.TabStop = False
        '
        'o86
        '
        Me.o86.Image = CType(resources.GetObject("o86.Image"), System.Drawing.Image)
        Me.o86.Location = New System.Drawing.Point(93, 532)
        Me.o86.Name = "o86"
        Me.o86.Size = New System.Drawing.Size(21, 23)
        Me.o86.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.o86.TabIndex = 2
        Me.o86.TabStop = False
        '
        'o2
        '
        Me.o2.Image = CType(resources.GetObject("o2.Image"), System.Drawing.Image)
        Me.o2.Location = New System.Drawing.Point(93, 234)
        Me.o2.Name = "o2"
        Me.o2.Size = New System.Drawing.Size(21, 23)
        Me.o2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.o2.TabIndex = 2
        Me.o2.TabStop = False
        '
        'o65
        '
        Me.o65.Image = CType(resources.GetObject("o65.Image"), System.Drawing.Image)
        Me.o65.Location = New System.Drawing.Point(93, 458)
        Me.o65.Name = "o65"
        Me.o65.Size = New System.Drawing.Size(21, 23)
        Me.o65.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.o65.TabIndex = 2
        Me.o65.TabStop = False
        '
        'o24
        '
        Me.o24.Image = CType(resources.GetObject("o24.Image"), System.Drawing.Image)
        Me.o24.Location = New System.Drawing.Point(147, 310)
        Me.o24.Name = "o24"
        Me.o24.Size = New System.Drawing.Size(21, 23)
        Me.o24.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.o24.TabIndex = 2
        Me.o24.TabStop = False
        '
        'o44
        '
        Me.o44.Image = CType(resources.GetObject("o44.Image"), System.Drawing.Image)
        Me.o44.Location = New System.Drawing.Point(93, 384)
        Me.o44.Name = "o44"
        Me.o44.Size = New System.Drawing.Size(21, 23)
        Me.o44.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.o44.TabIndex = 2
        Me.o44.TabStop = False
        '
        'o85
        '
        Me.o85.Image = CType(resources.GetObject("o85.Image"), System.Drawing.Image)
        Me.o85.Location = New System.Drawing.Point(39, 532)
        Me.o85.Name = "o85"
        Me.o85.Size = New System.Drawing.Size(21, 23)
        Me.o85.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.o85.TabIndex = 2
        Me.o85.TabStop = False
        '
        'o1
        '
        Me.o1.Image = CType(resources.GetObject("o1.Image"), System.Drawing.Image)
        Me.o1.Location = New System.Drawing.Point(39, 234)
        Me.o1.Name = "o1"
        Me.o1.Size = New System.Drawing.Size(21, 23)
        Me.o1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.o1.TabIndex = 2
        Me.o1.TabStop = False
        '
        'o64
        '
        Me.o64.Image = CType(resources.GetObject("o64.Image"), System.Drawing.Image)
        Me.o64.Location = New System.Drawing.Point(39, 458)
        Me.o64.Name = "o64"
        Me.o64.Size = New System.Drawing.Size(21, 23)
        Me.o64.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.o64.TabIndex = 2
        Me.o64.TabStop = False
        '
        'o23
        '
        Me.o23.Image = CType(resources.GetObject("o23.Image"), System.Drawing.Image)
        Me.o23.Location = New System.Drawing.Point(93, 310)
        Me.o23.Name = "o23"
        Me.o23.Size = New System.Drawing.Size(21, 23)
        Me.o23.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.o23.TabIndex = 2
        Me.o23.TabStop = False
        '
        'o43
        '
        Me.o43.Image = CType(resources.GetObject("o43.Image"), System.Drawing.Image)
        Me.o43.Location = New System.Drawing.Point(39, 384)
        Me.o43.Name = "o43"
        Me.o43.Size = New System.Drawing.Size(21, 23)
        Me.o43.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.o43.TabIndex = 2
        Me.o43.TabStop = False
        '
        'o22
        '
        Me.o22.Image = CType(resources.GetObject("o22.Image"), System.Drawing.Image)
        Me.o22.Location = New System.Drawing.Point(39, 310)
        Me.o22.Name = "o22"
        Me.o22.Size = New System.Drawing.Size(21, 23)
        Me.o22.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.o22.TabIndex = 2
        Me.o22.TabStop = False
        '
        'behainggi
        '
        Me.behainggi.Image = Global.WindowsApplication1.My.Resources.Resources.그림1
        Me.behainggi.Location = New System.Drawing.Point(242, 751)
        Me.behainggi.Name = "behainggi"
        Me.behainggi.Size = New System.Drawing.Size(100, 100)
        Me.behainggi.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.behainggi.TabIndex = 0
        Me.behainggi.TabStop = False
        '
        'picbullB
        '
        Me.picbullB.Image = Global.WindowsApplication1.My.Resources.Resources.그림1rf
        Me.picbullB.Location = New System.Drawing.Point(273, 785)
        Me.picbullB.Name = "picbullB"
        Me.picbullB.Size = New System.Drawing.Size(10, 38)
        Me.picbullB.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.picbullB.TabIndex = 1
        Me.picbullB.TabStop = False
        Me.picbullB.Visible = False
        '
        'picbullA
        '
        Me.picbullA.Image = Global.WindowsApplication1.My.Resources.Resources.그림1rf
        Me.picbullA.Location = New System.Drawing.Point(305, 785)
        Me.picbullA.Name = "picbullA"
        Me.picbullA.Size = New System.Drawing.Size(10, 38)
        Me.picbullA.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.picbullA.TabIndex = 1
        Me.picbullA.TabStop = False
        Me.picbullA.Visible = False
        '
        'picbullC
        '
        Me.picbullC.Image = Global.WindowsApplication1.My.Resources.Resources.그림1rf
        Me.picbullC.Location = New System.Drawing.Point(289, 763)
        Me.picbullC.Name = "picbullC"
        Me.picbullC.Size = New System.Drawing.Size(10, 38)
        Me.picbullC.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.picbullC.TabIndex = 1
        Me.picbullC.TabStop = False
        Me.picbullC.Visible = False
        '
        'o21
        '
        Me.o21.Image = CType(resources.GetObject("o21.Image"), System.Drawing.Image)
        Me.o21.Location = New System.Drawing.Point(551, 263)
        Me.o21.Name = "o21"
        Me.o21.Size = New System.Drawing.Size(21, 23)
        Me.o21.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.o21.TabIndex = 2
        Me.o21.TabStop = False
        '
        'o11
        '
        Me.o11.Image = CType(resources.GetObject("o11.Image"), System.Drawing.Image)
        Me.o11.Location = New System.Drawing.Point(12, 263)
        Me.o11.Name = "o11"
        Me.o11.Size = New System.Drawing.Size(21, 23)
        Me.o11.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.o11.TabIndex = 2
        Me.o11.TabStop = False
        '
        'o12
        '
        Me.o12.Image = CType(resources.GetObject("o12.Image"), System.Drawing.Image)
        Me.o12.Location = New System.Drawing.Point(66, 263)
        Me.o12.Name = "o12"
        Me.o12.Size = New System.Drawing.Size(21, 23)
        Me.o12.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.o12.TabIndex = 2
        Me.o12.TabStop = False
        '
        'o13
        '
        Me.o13.Image = CType(resources.GetObject("o13.Image"), System.Drawing.Image)
        Me.o13.Location = New System.Drawing.Point(120, 263)
        Me.o13.Name = "o13"
        Me.o13.Size = New System.Drawing.Size(21, 23)
        Me.o13.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.o13.TabIndex = 2
        Me.o13.TabStop = False
        '
        'o14
        '
        Me.o14.Image = CType(resources.GetObject("o14.Image"), System.Drawing.Image)
        Me.o14.Location = New System.Drawing.Point(174, 263)
        Me.o14.Name = "o14"
        Me.o14.Size = New System.Drawing.Size(21, 23)
        Me.o14.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.o14.TabIndex = 2
        Me.o14.TabStop = False
        '
        'o15
        '
        Me.o15.Image = CType(resources.GetObject("o15.Image"), System.Drawing.Image)
        Me.o15.Location = New System.Drawing.Point(228, 263)
        Me.o15.Name = "o15"
        Me.o15.Size = New System.Drawing.Size(21, 23)
        Me.o15.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.o15.TabIndex = 2
        Me.o15.TabStop = False
        '
        'o16
        '
        Me.o16.Image = CType(resources.GetObject("o16.Image"), System.Drawing.Image)
        Me.o16.Location = New System.Drawing.Point(282, 263)
        Me.o16.Name = "o16"
        Me.o16.Size = New System.Drawing.Size(21, 23)
        Me.o16.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.o16.TabIndex = 2
        Me.o16.TabStop = False
        '
        'o17
        '
        Me.o17.Image = CType(resources.GetObject("o17.Image"), System.Drawing.Image)
        Me.o17.Location = New System.Drawing.Point(336, 263)
        Me.o17.Name = "o17"
        Me.o17.Size = New System.Drawing.Size(21, 23)
        Me.o17.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.o17.TabIndex = 2
        Me.o17.TabStop = False
        '
        'o18
        '
        Me.o18.Image = CType(resources.GetObject("o18.Image"), System.Drawing.Image)
        Me.o18.Location = New System.Drawing.Point(390, 263)
        Me.o18.Name = "o18"
        Me.o18.Size = New System.Drawing.Size(21, 23)
        Me.o18.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.o18.TabIndex = 2
        Me.o18.TabStop = False
        '
        'o19
        '
        Me.o19.Image = CType(resources.GetObject("o19.Image"), System.Drawing.Image)
        Me.o19.Location = New System.Drawing.Point(444, 263)
        Me.o19.Name = "o19"
        Me.o19.Size = New System.Drawing.Size(21, 23)
        Me.o19.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.o19.TabIndex = 2
        Me.o19.TabStop = False
        '
        'o20
        '
        Me.o20.Image = CType(resources.GetObject("o20.Image"), System.Drawing.Image)
        Me.o20.Location = New System.Drawing.Point(498, 263)
        Me.o20.Name = "o20"
        Me.o20.Size = New System.Drawing.Size(21, 23)
        Me.o20.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.o20.TabIndex = 2
        Me.o20.TabStop = False
        '
        'o42
        '
        Me.o42.Image = CType(resources.GetObject("o42.Image"), System.Drawing.Image)
        Me.o42.Location = New System.Drawing.Point(551, 339)
        Me.o42.Name = "o42"
        Me.o42.Size = New System.Drawing.Size(21, 23)
        Me.o42.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.o42.TabIndex = 2
        Me.o42.TabStop = False
        '
        'o32
        '
        Me.o32.Image = CType(resources.GetObject("o32.Image"), System.Drawing.Image)
        Me.o32.Location = New System.Drawing.Point(12, 339)
        Me.o32.Name = "o32"
        Me.o32.Size = New System.Drawing.Size(21, 23)
        Me.o32.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.o32.TabIndex = 2
        Me.o32.TabStop = False
        '
        'o33
        '
        Me.o33.Image = CType(resources.GetObject("o33.Image"), System.Drawing.Image)
        Me.o33.Location = New System.Drawing.Point(66, 339)
        Me.o33.Name = "o33"
        Me.o33.Size = New System.Drawing.Size(21, 23)
        Me.o33.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.o33.TabIndex = 2
        Me.o33.TabStop = False
        '
        'o34
        '
        Me.o34.Image = CType(resources.GetObject("o34.Image"), System.Drawing.Image)
        Me.o34.Location = New System.Drawing.Point(120, 339)
        Me.o34.Name = "o34"
        Me.o34.Size = New System.Drawing.Size(21, 23)
        Me.o34.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.o34.TabIndex = 2
        Me.o34.TabStop = False
        '
        'o35
        '
        Me.o35.Image = CType(resources.GetObject("o35.Image"), System.Drawing.Image)
        Me.o35.Location = New System.Drawing.Point(174, 339)
        Me.o35.Name = "o35"
        Me.o35.Size = New System.Drawing.Size(21, 23)
        Me.o35.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.o35.TabIndex = 2
        Me.o35.TabStop = False
        '
        'o36
        '
        Me.o36.Image = CType(resources.GetObject("o36.Image"), System.Drawing.Image)
        Me.o36.Location = New System.Drawing.Point(228, 339)
        Me.o36.Name = "o36"
        Me.o36.Size = New System.Drawing.Size(21, 23)
        Me.o36.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.o36.TabIndex = 2
        Me.o36.TabStop = False
        '
        'o37
        '
        Me.o37.Image = CType(resources.GetObject("o37.Image"), System.Drawing.Image)
        Me.o37.Location = New System.Drawing.Point(282, 339)
        Me.o37.Name = "o37"
        Me.o37.Size = New System.Drawing.Size(21, 23)
        Me.o37.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.o37.TabIndex = 2
        Me.o37.TabStop = False
        '
        'o38
        '
        Me.o38.Image = CType(resources.GetObject("o38.Image"), System.Drawing.Image)
        Me.o38.Location = New System.Drawing.Point(336, 339)
        Me.o38.Name = "o38"
        Me.o38.Size = New System.Drawing.Size(21, 23)
        Me.o38.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.o38.TabIndex = 2
        Me.o38.TabStop = False
        '
        'o39
        '
        Me.o39.Image = CType(resources.GetObject("o39.Image"), System.Drawing.Image)
        Me.o39.Location = New System.Drawing.Point(390, 339)
        Me.o39.Name = "o39"
        Me.o39.Size = New System.Drawing.Size(21, 23)
        Me.o39.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.o39.TabIndex = 2
        Me.o39.TabStop = False
        '
        'o40
        '
        Me.o40.Image = CType(resources.GetObject("o40.Image"), System.Drawing.Image)
        Me.o40.Location = New System.Drawing.Point(444, 339)
        Me.o40.Name = "o40"
        Me.o40.Size = New System.Drawing.Size(21, 23)
        Me.o40.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.o40.TabIndex = 2
        Me.o40.TabStop = False
        '
        'o41
        '
        Me.o41.Image = CType(resources.GetObject("o41.Image"), System.Drawing.Image)
        Me.o41.Location = New System.Drawing.Point(498, 339)
        Me.o41.Name = "o41"
        Me.o41.Size = New System.Drawing.Size(21, 23)
        Me.o41.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.o41.TabIndex = 2
        Me.o41.TabStop = False
        '
        'o63
        '
        Me.o63.Image = CType(resources.GetObject("o63.Image"), System.Drawing.Image)
        Me.o63.Location = New System.Drawing.Point(551, 413)
        Me.o63.Name = "o63"
        Me.o63.Size = New System.Drawing.Size(21, 23)
        Me.o63.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.o63.TabIndex = 2
        Me.o63.TabStop = False
        '
        'o53
        '
        Me.o53.Image = CType(resources.GetObject("o53.Image"), System.Drawing.Image)
        Me.o53.Location = New System.Drawing.Point(12, 413)
        Me.o53.Name = "o53"
        Me.o53.Size = New System.Drawing.Size(21, 23)
        Me.o53.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.o53.TabIndex = 2
        Me.o53.TabStop = False
        '
        'o54
        '
        Me.o54.Image = CType(resources.GetObject("o54.Image"), System.Drawing.Image)
        Me.o54.Location = New System.Drawing.Point(66, 413)
        Me.o54.Name = "o54"
        Me.o54.Size = New System.Drawing.Size(21, 23)
        Me.o54.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.o54.TabIndex = 2
        Me.o54.TabStop = False
        '
        'o55
        '
        Me.o55.Image = CType(resources.GetObject("o55.Image"), System.Drawing.Image)
        Me.o55.Location = New System.Drawing.Point(120, 413)
        Me.o55.Name = "o55"
        Me.o55.Size = New System.Drawing.Size(21, 23)
        Me.o55.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.o55.TabIndex = 2
        Me.o55.TabStop = False
        '
        'o56
        '
        Me.o56.Image = CType(resources.GetObject("o56.Image"), System.Drawing.Image)
        Me.o56.Location = New System.Drawing.Point(174, 413)
        Me.o56.Name = "o56"
        Me.o56.Size = New System.Drawing.Size(21, 23)
        Me.o56.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.o56.TabIndex = 2
        Me.o56.TabStop = False
        '
        'o57
        '
        Me.o57.Image = CType(resources.GetObject("o57.Image"), System.Drawing.Image)
        Me.o57.Location = New System.Drawing.Point(228, 413)
        Me.o57.Name = "o57"
        Me.o57.Size = New System.Drawing.Size(21, 23)
        Me.o57.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.o57.TabIndex = 2
        Me.o57.TabStop = False
        '
        'o58
        '
        Me.o58.Image = CType(resources.GetObject("o58.Image"), System.Drawing.Image)
        Me.o58.Location = New System.Drawing.Point(282, 413)
        Me.o58.Name = "o58"
        Me.o58.Size = New System.Drawing.Size(21, 23)
        Me.o58.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.o58.TabIndex = 2
        Me.o58.TabStop = False
        '
        'o59
        '
        Me.o59.Image = CType(resources.GetObject("o59.Image"), System.Drawing.Image)
        Me.o59.Location = New System.Drawing.Point(336, 413)
        Me.o59.Name = "o59"
        Me.o59.Size = New System.Drawing.Size(21, 23)
        Me.o59.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.o59.TabIndex = 2
        Me.o59.TabStop = False
        '
        'o60
        '
        Me.o60.Image = CType(resources.GetObject("o60.Image"), System.Drawing.Image)
        Me.o60.Location = New System.Drawing.Point(390, 413)
        Me.o60.Name = "o60"
        Me.o60.Size = New System.Drawing.Size(21, 23)
        Me.o60.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.o60.TabIndex = 2
        Me.o60.TabStop = False
        '
        'o61
        '
        Me.o61.Image = CType(resources.GetObject("o61.Image"), System.Drawing.Image)
        Me.o61.Location = New System.Drawing.Point(444, 413)
        Me.o61.Name = "o61"
        Me.o61.Size = New System.Drawing.Size(21, 23)
        Me.o61.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.o61.TabIndex = 2
        Me.o61.TabStop = False
        '
        'o62
        '
        Me.o62.Image = CType(resources.GetObject("o62.Image"), System.Drawing.Image)
        Me.o62.Location = New System.Drawing.Point(498, 413)
        Me.o62.Name = "o62"
        Me.o62.Size = New System.Drawing.Size(21, 23)
        Me.o62.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.o62.TabIndex = 2
        Me.o62.TabStop = False
        '
        'o84
        '
        Me.o84.Image = CType(resources.GetObject("o84.Image"), System.Drawing.Image)
        Me.o84.Location = New System.Drawing.Point(551, 487)
        Me.o84.Name = "o84"
        Me.o84.Size = New System.Drawing.Size(21, 23)
        Me.o84.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.o84.TabIndex = 2
        Me.o84.TabStop = False
        '
        'o74
        '
        Me.o74.Image = CType(resources.GetObject("o74.Image"), System.Drawing.Image)
        Me.o74.Location = New System.Drawing.Point(12, 487)
        Me.o74.Name = "o74"
        Me.o74.Size = New System.Drawing.Size(21, 23)
        Me.o74.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.o74.TabIndex = 2
        Me.o74.TabStop = False
        '
        'o75
        '
        Me.o75.Image = CType(resources.GetObject("o75.Image"), System.Drawing.Image)
        Me.o75.Location = New System.Drawing.Point(66, 487)
        Me.o75.Name = "o75"
        Me.o75.Size = New System.Drawing.Size(21, 23)
        Me.o75.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.o75.TabIndex = 2
        Me.o75.TabStop = False
        '
        'o76
        '
        Me.o76.Image = CType(resources.GetObject("o76.Image"), System.Drawing.Image)
        Me.o76.Location = New System.Drawing.Point(120, 487)
        Me.o76.Name = "o76"
        Me.o76.Size = New System.Drawing.Size(21, 23)
        Me.o76.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.o76.TabIndex = 2
        Me.o76.TabStop = False
        '
        'o77
        '
        Me.o77.Image = CType(resources.GetObject("o77.Image"), System.Drawing.Image)
        Me.o77.Location = New System.Drawing.Point(174, 487)
        Me.o77.Name = "o77"
        Me.o77.Size = New System.Drawing.Size(21, 23)
        Me.o77.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.o77.TabIndex = 2
        Me.o77.TabStop = False
        '
        'o78
        '
        Me.o78.Image = CType(resources.GetObject("o78.Image"), System.Drawing.Image)
        Me.o78.Location = New System.Drawing.Point(228, 487)
        Me.o78.Name = "o78"
        Me.o78.Size = New System.Drawing.Size(21, 23)
        Me.o78.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.o78.TabIndex = 2
        Me.o78.TabStop = False
        '
        'o79
        '
        Me.o79.Image = CType(resources.GetObject("o79.Image"), System.Drawing.Image)
        Me.o79.Location = New System.Drawing.Point(282, 487)
        Me.o79.Name = "o79"
        Me.o79.Size = New System.Drawing.Size(21, 23)
        Me.o79.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.o79.TabIndex = 2
        Me.o79.TabStop = False
        '
        'o80
        '
        Me.o80.Image = CType(resources.GetObject("o80.Image"), System.Drawing.Image)
        Me.o80.Location = New System.Drawing.Point(336, 487)
        Me.o80.Name = "o80"
        Me.o80.Size = New System.Drawing.Size(21, 23)
        Me.o80.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.o80.TabIndex = 2
        Me.o80.TabStop = False
        '
        'o81
        '
        Me.o81.Image = CType(resources.GetObject("o81.Image"), System.Drawing.Image)
        Me.o81.Location = New System.Drawing.Point(390, 487)
        Me.o81.Name = "o81"
        Me.o81.Size = New System.Drawing.Size(21, 23)
        Me.o81.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.o81.TabIndex = 2
        Me.o81.TabStop = False
        '
        'o82
        '
        Me.o82.Image = CType(resources.GetObject("o82.Image"), System.Drawing.Image)
        Me.o82.Location = New System.Drawing.Point(444, 487)
        Me.o82.Name = "o82"
        Me.o82.Size = New System.Drawing.Size(21, 23)
        Me.o82.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.o82.TabIndex = 2
        Me.o82.TabStop = False
        '
        'o83
        '
        Me.o83.Image = CType(resources.GetObject("o83.Image"), System.Drawing.Image)
        Me.o83.Location = New System.Drawing.Point(498, 487)
        Me.o83.Name = "o83"
        Me.o83.Size = New System.Drawing.Size(21, 23)
        Me.o83.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.o83.TabIndex = 2
        Me.o83.TabStop = False
        '
        'o105
        '
        Me.o105.Image = CType(resources.GetObject("o105.Image"), System.Drawing.Image)
        Me.o105.Location = New System.Drawing.Point(551, 561)
        Me.o105.Name = "o105"
        Me.o105.Size = New System.Drawing.Size(21, 23)
        Me.o105.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.o105.TabIndex = 2
        Me.o105.TabStop = False
        '
        'o95
        '
        Me.o95.Image = CType(resources.GetObject("o95.Image"), System.Drawing.Image)
        Me.o95.Location = New System.Drawing.Point(12, 561)
        Me.o95.Name = "o95"
        Me.o95.Size = New System.Drawing.Size(21, 23)
        Me.o95.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.o95.TabIndex = 2
        Me.o95.TabStop = False
        '
        'o96
        '
        Me.o96.Image = CType(resources.GetObject("o96.Image"), System.Drawing.Image)
        Me.o96.Location = New System.Drawing.Point(66, 561)
        Me.o96.Name = "o96"
        Me.o96.Size = New System.Drawing.Size(21, 23)
        Me.o96.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.o96.TabIndex = 2
        Me.o96.TabStop = False
        '
        'o97
        '
        Me.o97.Image = CType(resources.GetObject("o97.Image"), System.Drawing.Image)
        Me.o97.Location = New System.Drawing.Point(120, 561)
        Me.o97.Name = "o97"
        Me.o97.Size = New System.Drawing.Size(21, 23)
        Me.o97.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.o97.TabIndex = 2
        Me.o97.TabStop = False
        '
        'o98
        '
        Me.o98.Image = CType(resources.GetObject("o98.Image"), System.Drawing.Image)
        Me.o98.Location = New System.Drawing.Point(174, 561)
        Me.o98.Name = "o98"
        Me.o98.Size = New System.Drawing.Size(21, 23)
        Me.o98.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.o98.TabIndex = 2
        Me.o98.TabStop = False
        '
        'o99
        '
        Me.o99.Image = CType(resources.GetObject("o99.Image"), System.Drawing.Image)
        Me.o99.Location = New System.Drawing.Point(228, 561)
        Me.o99.Name = "o99"
        Me.o99.Size = New System.Drawing.Size(21, 23)
        Me.o99.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.o99.TabIndex = 2
        Me.o99.TabStop = False
        '
        'o100
        '
        Me.o100.Image = CType(resources.GetObject("o100.Image"), System.Drawing.Image)
        Me.o100.Location = New System.Drawing.Point(282, 561)
        Me.o100.Name = "o100"
        Me.o100.Size = New System.Drawing.Size(21, 23)
        Me.o100.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.o100.TabIndex = 2
        Me.o100.TabStop = False
        '
        'o101
        '
        Me.o101.Image = CType(resources.GetObject("o101.Image"), System.Drawing.Image)
        Me.o101.Location = New System.Drawing.Point(336, 561)
        Me.o101.Name = "o101"
        Me.o101.Size = New System.Drawing.Size(21, 23)
        Me.o101.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.o101.TabIndex = 2
        Me.o101.TabStop = False
        '
        'o102
        '
        Me.o102.Image = CType(resources.GetObject("o102.Image"), System.Drawing.Image)
        Me.o102.Location = New System.Drawing.Point(390, 561)
        Me.o102.Name = "o102"
        Me.o102.Size = New System.Drawing.Size(21, 23)
        Me.o102.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.o102.TabIndex = 2
        Me.o102.TabStop = False
        '
        'o103
        '
        Me.o103.Image = CType(resources.GetObject("o103.Image"), System.Drawing.Image)
        Me.o103.Location = New System.Drawing.Point(444, 561)
        Me.o103.Name = "o103"
        Me.o103.Size = New System.Drawing.Size(21, 23)
        Me.o103.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.o103.TabIndex = 2
        Me.o103.TabStop = False
        '
        'o104
        '
        Me.o104.Image = CType(resources.GetObject("o104.Image"), System.Drawing.Image)
        Me.o104.Location = New System.Drawing.Point(498, 561)
        Me.o104.Name = "o104"
        Me.o104.Size = New System.Drawing.Size(21, 23)
        Me.o104.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.o104.TabIndex = 2
        Me.o104.TabStop = False
        '
        'oBoss
        '
        Me.oBoss.Image = CType(resources.GetObject("oBoss.Image"), System.Drawing.Image)
        Me.oBoss.Location = New System.Drawing.Point(227, 32)
        Me.oBoss.Name = "oBoss"
        Me.oBoss.Size = New System.Drawing.Size(130, 130)
        Me.oBoss.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.oBoss.TabIndex = 2
        Me.oBoss.TabStop = False
        '
        'ddd
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(7.0!, 12.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(584, 862)
        Me.Controls.Add(Me.o94)
        Me.Controls.Add(Me.o10)
        Me.Controls.Add(Me.o73)
        Me.Controls.Add(Me.o52)
        Me.Controls.Add(Me.o31)
        Me.Controls.Add(Me.o104)
        Me.Controls.Add(Me.o83)
        Me.Controls.Add(Me.o62)
        Me.Controls.Add(Me.o41)
        Me.Controls.Add(Me.o20)
        Me.Controls.Add(Me.o93)
        Me.Controls.Add(Me.o72)
        Me.Controls.Add(Me.o9)
        Me.Controls.Add(Me.o51)
        Me.Controls.Add(Me.o30)
        Me.Controls.Add(Me.o103)
        Me.Controls.Add(Me.o82)
        Me.Controls.Add(Me.o61)
        Me.Controls.Add(Me.o40)
        Me.Controls.Add(Me.o19)
        Me.Controls.Add(Me.o92)
        Me.Controls.Add(Me.o71)
        Me.Controls.Add(Me.o8)
        Me.Controls.Add(Me.o50)
        Me.Controls.Add(Me.o29)
        Me.Controls.Add(Me.o102)
        Me.Controls.Add(Me.o81)
        Me.Controls.Add(Me.o60)
        Me.Controls.Add(Me.o39)
        Me.Controls.Add(Me.o18)
        Me.Controls.Add(Me.o91)
        Me.Controls.Add(Me.o70)
        Me.Controls.Add(Me.o7)
        Me.Controls.Add(Me.o49)
        Me.Controls.Add(Me.o28)
        Me.Controls.Add(Me.o101)
        Me.Controls.Add(Me.o80)
        Me.Controls.Add(Me.o59)
        Me.Controls.Add(Me.o38)
        Me.Controls.Add(Me.o17)
        Me.Controls.Add(Me.o90)
        Me.Controls.Add(Me.o6)
        Me.Controls.Add(Me.o69)
        Me.Controls.Add(Me.o48)
        Me.Controls.Add(Me.o89)
        Me.Controls.Add(Me.o5)
        Me.Controls.Add(Me.o68)
        Me.Controls.Add(Me.o100)
        Me.Controls.Add(Me.o79)
        Me.Controls.Add(Me.o58)
        Me.Controls.Add(Me.o37)
        Me.Controls.Add(Me.o16)
        Me.Controls.Add(Me.o27)
        Me.Controls.Add(Me.o47)
        Me.Controls.Add(Me.o88)
        Me.Controls.Add(Me.o4)
        Me.Controls.Add(Me.o67)
        Me.Controls.Add(Me.o99)
        Me.Controls.Add(Me.o78)
        Me.Controls.Add(Me.o57)
        Me.Controls.Add(Me.o36)
        Me.Controls.Add(Me.o15)
        Me.Controls.Add(Me.o26)
        Me.Controls.Add(Me.o46)
        Me.Controls.Add(Me.o87)
        Me.Controls.Add(Me.o3)
        Me.Controls.Add(Me.o66)
        Me.Controls.Add(Me.o98)
        Me.Controls.Add(Me.o77)
        Me.Controls.Add(Me.o56)
        Me.Controls.Add(Me.o35)
        Me.Controls.Add(Me.o14)
        Me.Controls.Add(Me.o25)
        Me.Controls.Add(Me.o45)
        Me.Controls.Add(Me.o86)
        Me.Controls.Add(Me.o2)
        Me.Controls.Add(Me.o65)
        Me.Controls.Add(Me.o97)
        Me.Controls.Add(Me.o76)
        Me.Controls.Add(Me.o55)
        Me.Controls.Add(Me.o34)
        Me.Controls.Add(Me.o13)
        Me.Controls.Add(Me.o24)
        Me.Controls.Add(Me.o44)
        Me.Controls.Add(Me.o85)
        Me.Controls.Add(Me.o1)
        Me.Controls.Add(Me.o64)
        Me.Controls.Add(Me.o96)
        Me.Controls.Add(Me.o75)
        Me.Controls.Add(Me.o54)
        Me.Controls.Add(Me.o33)
        Me.Controls.Add(Me.o12)
        Me.Controls.Add(Me.o23)
        Me.Controls.Add(Me.o43)
        Me.Controls.Add(Me.o95)
        Me.Controls.Add(Me.o74)
        Me.Controls.Add(Me.o53)
        Me.Controls.Add(Me.o32)
        Me.Controls.Add(Me.o11)
        Me.Controls.Add(Me.o22)
        Me.Controls.Add(Me.o105)
        Me.Controls.Add(Me.o84)
        Me.Controls.Add(Me.o63)
        Me.Controls.Add(Me.o42)
        Me.Controls.Add(Me.o21)
        Me.Controls.Add(Me.oBoss)
        Me.Controls.Add(Me.behainggi)
        Me.Controls.Add(Me.picbullB)
        Me.Controls.Add(Me.picbullA)
        Me.Controls.Add(Me.picbullC)
        Me.MaximizeBox = False
        Me.MaximumSize = New System.Drawing.Size(600, 900)
        Me.MinimizeBox = False
        Me.MinimumSize = New System.Drawing.Size(600, 900)
        Me.Name = "ddd"
        Me.Text = "Game"
        CType(Me.o94, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.o10, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.o73, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.o52, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.o31, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.o93, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.o72, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.o9, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.o51, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.o30, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.o92, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.o71, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.o8, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.o50, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.o29, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.o91, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.o70, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.o7, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.o49, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.o28, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.o90, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.o6, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.o69, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.o48, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.o89, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.o5, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.o68, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.o27, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.o47, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.o88, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.o4, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.o67, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.o26, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.o46, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.o87, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.o3, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.o66, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.o25, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.o45, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.o86, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.o2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.o65, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.o24, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.o44, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.o85, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.o1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.o64, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.o23, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.o43, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.o22, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.behainggi, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picbullB, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picbullA, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picbullC, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.o21, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.o11, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.o12, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.o13, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.o14, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.o15, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.o16, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.o17, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.o18, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.o19, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.o20, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.o42, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.o32, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.o33, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.o34, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.o35, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.o36, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.o37, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.o38, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.o39, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.o40, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.o41, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.o63, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.o53, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.o54, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.o55, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.o56, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.o57, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.o58, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.o59, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.o60, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.o61, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.o62, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.o84, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.o74, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.o75, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.o76, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.o77, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.o78, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.o79, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.o80, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.o81, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.o82, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.o83, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.o105, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.o95, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.o96, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.o97, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.o98, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.o99, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.o100, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.o101, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.o102, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.o103, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.o104, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.oBoss, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents behainggi As System.Windows.Forms.PictureBox
    Friend WithEvents picbullC As System.Windows.Forms.PictureBox
    Friend WithEvents picbullA As System.Windows.Forms.PictureBox
    Friend WithEvents picbullB As System.Windows.Forms.PictureBox
    Friend WithEvents o1 As System.Windows.Forms.PictureBox
    Friend WithEvents o2 As System.Windows.Forms.PictureBox
    Friend WithEvents o3 As System.Windows.Forms.PictureBox
    Friend WithEvents o4 As System.Windows.Forms.PictureBox
    Friend WithEvents o5 As System.Windows.Forms.PictureBox
    Friend WithEvents o6 As System.Windows.Forms.PictureBox
    Friend WithEvents o7 As System.Windows.Forms.PictureBox
    Friend WithEvents o8 As System.Windows.Forms.PictureBox
    Friend WithEvents o9 As System.Windows.Forms.PictureBox
    Friend WithEvents o10 As System.Windows.Forms.PictureBox
    Friend WithEvents o22 As System.Windows.Forms.PictureBox
    Friend WithEvents o43 As System.Windows.Forms.PictureBox
    Friend WithEvents o23 As System.Windows.Forms.PictureBox
    Friend WithEvents o64 As System.Windows.Forms.PictureBox
    Friend WithEvents o85 As System.Windows.Forms.PictureBox
    Friend WithEvents o44 As System.Windows.Forms.PictureBox
    Friend WithEvents o24 As System.Windows.Forms.PictureBox
    Friend WithEvents o65 As System.Windows.Forms.PictureBox
    Friend WithEvents o86 As System.Windows.Forms.PictureBox
    Friend WithEvents o45 As System.Windows.Forms.PictureBox
    Friend WithEvents o25 As System.Windows.Forms.PictureBox
    Friend WithEvents o66 As System.Windows.Forms.PictureBox
    Friend WithEvents o87 As System.Windows.Forms.PictureBox
    Friend WithEvents o46 As System.Windows.Forms.PictureBox
    Friend WithEvents o26 As System.Windows.Forms.PictureBox
    Friend WithEvents o67 As System.Windows.Forms.PictureBox
    Friend WithEvents o88 As System.Windows.Forms.PictureBox
    Friend WithEvents o47 As System.Windows.Forms.PictureBox
    Friend WithEvents o27 As System.Windows.Forms.PictureBox
    Friend WithEvents o68 As System.Windows.Forms.PictureBox
    Friend WithEvents o89 As System.Windows.Forms.PictureBox
    Friend WithEvents o48 As System.Windows.Forms.PictureBox
    Friend WithEvents o69 As System.Windows.Forms.PictureBox
    Friend WithEvents o90 As System.Windows.Forms.PictureBox
    Friend WithEvents o28 As System.Windows.Forms.PictureBox
    Friend WithEvents o49 As System.Windows.Forms.PictureBox
    Friend WithEvents o70 As System.Windows.Forms.PictureBox
    Friend WithEvents o91 As System.Windows.Forms.PictureBox
    Friend WithEvents o29 As System.Windows.Forms.PictureBox
    Friend WithEvents o50 As System.Windows.Forms.PictureBox
    Friend WithEvents o71 As System.Windows.Forms.PictureBox
    Friend WithEvents o92 As System.Windows.Forms.PictureBox
    Friend WithEvents o30 As System.Windows.Forms.PictureBox
    Friend WithEvents o51 As System.Windows.Forms.PictureBox
    Friend WithEvents o72 As System.Windows.Forms.PictureBox
    Friend WithEvents o93 As System.Windows.Forms.PictureBox
    Friend WithEvents o31 As System.Windows.Forms.PictureBox
    Friend WithEvents o52 As System.Windows.Forms.PictureBox
    Friend WithEvents o73 As System.Windows.Forms.PictureBox
    Friend WithEvents o94 As System.Windows.Forms.PictureBox
    Friend WithEvents o21 As System.Windows.Forms.PictureBox
    Friend WithEvents o11 As System.Windows.Forms.PictureBox
    Friend WithEvents o12 As System.Windows.Forms.PictureBox
    Friend WithEvents o13 As System.Windows.Forms.PictureBox
    Friend WithEvents o14 As System.Windows.Forms.PictureBox
    Friend WithEvents o15 As System.Windows.Forms.PictureBox
    Friend WithEvents o16 As System.Windows.Forms.PictureBox
    Friend WithEvents o17 As System.Windows.Forms.PictureBox
    Friend WithEvents o18 As System.Windows.Forms.PictureBox
    Friend WithEvents o19 As System.Windows.Forms.PictureBox
    Friend WithEvents o20 As System.Windows.Forms.PictureBox
    Friend WithEvents o42 As System.Windows.Forms.PictureBox
    Friend WithEvents o32 As System.Windows.Forms.PictureBox
    Friend WithEvents o33 As System.Windows.Forms.PictureBox
    Friend WithEvents o34 As System.Windows.Forms.PictureBox
    Friend WithEvents o35 As System.Windows.Forms.PictureBox
    Friend WithEvents o36 As System.Windows.Forms.PictureBox
    Friend WithEvents o37 As System.Windows.Forms.PictureBox
    Friend WithEvents o38 As System.Windows.Forms.PictureBox
    Friend WithEvents o39 As System.Windows.Forms.PictureBox
    Friend WithEvents o40 As System.Windows.Forms.PictureBox
    Friend WithEvents o41 As System.Windows.Forms.PictureBox
    Friend WithEvents o63 As System.Windows.Forms.PictureBox
    Friend WithEvents o53 As System.Windows.Forms.PictureBox
    Friend WithEvents o54 As System.Windows.Forms.PictureBox
    Friend WithEvents o55 As System.Windows.Forms.PictureBox
    Friend WithEvents o56 As System.Windows.Forms.PictureBox
    Friend WithEvents o57 As System.Windows.Forms.PictureBox
    Friend WithEvents o58 As System.Windows.Forms.PictureBox
    Friend WithEvents o59 As System.Windows.Forms.PictureBox
    Friend WithEvents o60 As System.Windows.Forms.PictureBox
    Friend WithEvents o61 As System.Windows.Forms.PictureBox
    Friend WithEvents o62 As System.Windows.Forms.PictureBox
    Friend WithEvents o84 As System.Windows.Forms.PictureBox
    Friend WithEvents o74 As System.Windows.Forms.PictureBox
    Friend WithEvents o75 As System.Windows.Forms.PictureBox
    Friend WithEvents o76 As System.Windows.Forms.PictureBox
    Friend WithEvents o77 As System.Windows.Forms.PictureBox
    Friend WithEvents o78 As System.Windows.Forms.PictureBox
    Friend WithEvents o79 As System.Windows.Forms.PictureBox
    Friend WithEvents o80 As System.Windows.Forms.PictureBox
    Friend WithEvents o81 As System.Windows.Forms.PictureBox
    Friend WithEvents o82 As System.Windows.Forms.PictureBox
    Friend WithEvents o83 As System.Windows.Forms.PictureBox
    Friend WithEvents o105 As System.Windows.Forms.PictureBox
    Friend WithEvents o95 As System.Windows.Forms.PictureBox
    Friend WithEvents o96 As System.Windows.Forms.PictureBox
    Friend WithEvents o97 As System.Windows.Forms.PictureBox
    Friend WithEvents o98 As System.Windows.Forms.PictureBox
    Friend WithEvents o99 As System.Windows.Forms.PictureBox
    Friend WithEvents o100 As System.Windows.Forms.PictureBox
    Friend WithEvents o101 As System.Windows.Forms.PictureBox
    Friend WithEvents o102 As System.Windows.Forms.PictureBox
    Friend WithEvents o103 As System.Windows.Forms.PictureBox
    Friend WithEvents o104 As System.Windows.Forms.PictureBox
    Friend WithEvents oBoss As System.Windows.Forms.PictureBox

End Class
