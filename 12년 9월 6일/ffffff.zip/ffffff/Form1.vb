﻿Public Class Form1

    Private Sub PictureBox1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles be.Click

    End Sub

    Private Sub Form1_KeyDown(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles Me.KeyDown
        If e.KeyValue = Keys.Right Then
            be.Left += 5
            If be.Left = 600 Then
                be.Left = -50
            End If

        End If

        If e.KeyValue = Keys.Left Then
            be.Left -= 5
            If be.Left = -50 Then
                be.Left = 600

            End If

        End If

        If e.KeyValue = Keys.Space Then
            ten.Left = be.Left + 20
            ten.Visible = True
            ' tom.Enabled = true

        End If
    End Sub

    Private Sub ten_start()
        If ten.Visible = True Then
            ten.Top -= 20
        End If

    End Sub

    Private Sub ten_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ten.Click

    End Sub
End Class

